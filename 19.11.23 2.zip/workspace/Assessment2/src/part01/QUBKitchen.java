package part01;

import java.util.ArrayList;
import java.util.InputMismatchException;

public class QUBKitchen {
	private static ArrayList<Ingredient> listOfIngredients = new ArrayList<Ingredient>();
	private static ArrayList<Recipe> listOfRecipes = new ArrayList<Recipe>();
	private static int amountOfIngredients;

	public static void main(String[] args) {
		while (true) {
			try {
				Menu mainMenu = new Menu("Queen's University Belfast Kitchen",
						new String[] { "Manage Ingredients", "Manage Recipes", "Manage the Weekly Menu", "Exit" });
				switch (mainMenu.getUserChoice()) {
				case (1):
					// Manage Ingredients
					manageIngredientsMenu();
					break;
				case (2):
					// Manage Recipes
					manageRecipesMenu();
					break;
				case (3):
					// Manage the Weekly Menu
					break;
				case (4):
					// Exit
					System.out.println("Happy to help! Closing now.");
					System.exit(0);
					break;
				}
			} catch (Exception ex) {
				System.out.println("\nSorry! That Selection was invalid. Please try again!\n");
			}
		}
	}

	private static void manageIngredientsMenu() {
		boolean valid = false;
		while (!valid) {
			try {
				System.out.println("");
				Menu ingredientMenu = new Menu("Manage Ingredients",
						new String[] { "Add an Ingredient Type", "Delete an Ingredient Type",
								"Delete all Ingredient Types", "View an Ingredient Type", "View all Ingredient Types",
								"Update an Ingredient Type", "Back" });
				switch (ingredientMenu.getUserChoice()) {
				case (1):
					// Add an Ingredient Type
					addObject("Ingredient");
					break;
				case (2):
					// Delete an Ingredient Type
					deleteObject("Ingredient");
					break;
				case (3):
					// Delete all Ingredient Types
					wipeListOfObject("Ingredient");
					break;
				case (4):
					// View an Ingredient Type
					viewObjectSpecific("Ingredient");
					break;
				case (5):
					// View all Ingredient Types
					viewAllObject("Ingredient");
					break;
				case (6):
					// Update an Ingredient Type
					updateObject("Ingredient");
					break;
				case (7):
					valid = true;
					break;
				default:
					throw new Exception();
				}
			} catch (Exception ex) {
				System.out.println("\nSorry! That Selection was invalid. Please try again!");
			}
		}
	}

	private static void manageRecipesMenu() {
		boolean valid = false;
		while (!valid) {
			try {
				System.out.println("");
				Menu recipeMenu = new Menu("Manage Recipes",
						new String[] { "Add a Recipe", "Delete a Recipe", "Delete all Recipes",
								"View all Ingredient Types", "View a Recipe", "Update a Recipe", "Back" });
				switch (recipeMenu.getUserChoice()) {
				case (1):
					// Add a Recipe
					addObject("Recipe");
					break;
				case (2):
					// Delete a Recipe
					deleteObject("Recipe");
					break;
				case (3):
					// Delete all Recipes
					wipeListOfObject("Recipe");
					break;
				case (4):
					// View a Recipe
					viewObjectSpecific("Recipe");
					break;
				case (5):
					// View all Recipes
					viewAllObject("Recipe");
					break;
				case (6):
					// Update a Recipe
					updateObject("Recipe");
					break;
				case (7):
					valid = true;
					break;
				default:
					throw new Exception();
				}
			} catch (Exception ex) {
				System.out.println("\nSorry! That Selection was invalid. Please try again!");
			}
		}
	}

	private static void addObject(String type) {
		Ingredient toAddI;
		Recipe toAddR;
		try {
			switch (type) {
			case "Ingredient":
				System.out.println("Adding an Ingredient Type:");
				toAddI = new Ingredient(takeName(), takeFoodType(), takeCaloriesPer100Grams());
				listOfIngredients.add(toAddI);
				System.out.println(toAddI.toString());
				break;
			case "Recipe":
				System.out.println("Adding a Recipe Type:");
				toAddR = new Recipe(takeName(), takeIngredients(), takeStringArray("IngredientsGuidance"),
						takeStringArray("RecipeInstructions"));
				listOfRecipes.add(toAddR);
				System.out.println(toAddR.toString());
				break;
			}
		} catch (Exception e) {
			System.out.println("Sorry, an error has occurred in construction. Please try again.");
		}
	}

	private static void deleteObject(String type) {
		try {
			System.out.println("\nDeleting " + type + ":");
			switch (type) {
			case "Ingredient":
				if (listOfIngredients.isEmpty()) {
					throw new InputMismatchException();
				}
				Ingredient i = takeIngredient();
				if (i != null) {
					listOfIngredients.remove(i);
					System.out.println("\nThe Ingredient has been deleted.");}
					break;
			case "Recipe":
				if (listOfRecipes.isEmpty()) {
					throw new InputMismatchException();
				}
				Recipe r = takeRecipe();
				if (r != null) {
					listOfRecipes.remove(r);
					System.out.println("\nThe Ingredient has been deleted.");
				}
				break;
			}
		}catch (InputMismatchException iex) {
			System.out.println("\nSorry! There are no " + type + "s saved to be deleted.");
		}
		catch (Exception ex) {}
	}

	private static void viewObjectSpecific(String type) {
		try {
			System.out.println("\nViewing Specific " + type + ":");
			switch (type) {
			case "Ingredient":
				if (listOfIngredients.isEmpty()) {
					throw new InputMismatchException();
				}
				System.out.println("\nSelected Ingredient:\n" + takeIngredient().toString());
				break;
			case "Recipe":
				if (listOfIngredients.isEmpty()) {
					throw new InputMismatchException();
				}
				System.out.println("\n" + takeRecipe().toString());
				break;
			}

		} catch (InputMismatchException ex) {
			System.out.println("\nSorry, there are no " + type + "s saved to view.");
		}
		catch(Exception ex) {}
	}

	private static void viewAllObject(String type) {
		System.out.println("\nViewing all "+type+"s:\n");
		switch (type) {
		case ("Recipe"): {
			if (!listOfRecipes.isEmpty()) {
				int count =0;
				for (Recipe r : listOfRecipes) {
					System.out.print("Recipe "+ ++count+":\n"+r.toString());
				}
			} else {
				System.out.println("\nSorry, there are no " + type + "s saved to view.");
			}
		}
		case ("Ingredient"): {
			if (!listOfIngredients.isEmpty()) {
				int count=0;
				for (Ingredient i : listOfIngredients) {
					System.out.println("Ingredient "+ ++count+":\n"+i.toString()+"\n");
				}
			} else {
				System.out.println("\nSorry, there are no " + type + "s saved to view.");
			}
			break;
		}
		}
	}

	private static void wipeListOfObject(String type) {
		switch (type) {
		case ("Ingredient"):
			listOfIngredients.clear();
			break;
		case ("Recipe"):
			listOfRecipes.clear();
			break;
		}
		System.out.println("\nAll " + type + "s have been deleted.");
	}

	private static void updateObject(String type) {
		try {
			switch (type) {
			case "Ingredient":
				if (listOfIngredients.isEmpty()) {
					throw new Exception();
				}
				Ingredient toUpdateI = takeIngredient();
				System.out.print("\nUpdating Ingredient:\n" + toUpdateI.toString()
						+ "\n1: Name\n2: Food Type\n3: Calories Per 100 Grams\n\nSelect field to Update:");
				switch (Utility.takeIntFromScanner()) {
				case 1:
					toUpdateI.setIngredientName(takeName());
					System.out.println("Name has been updated.");
					break;
				case 2:
					toUpdateI.setFoodType(takeFoodType());
					System.out.println("Food Type has been updated.");
					break;
				case 3:
					toUpdateI.setCaloriesPer100Grams(takeCaloriesPer100Grams());
					System.out.println("Calories per 100 Grams has been updated.");
					break;
				default:
					throw new Exception("Invalid Input.");
				}
				break;
			case "Recipe":
				if (listOfRecipes.isEmpty()) {
					throw new Exception();
				}
				Recipe toUpdateR = takeRecipe();
				System.out.print("Updating Recipe:\n" + toUpdateR.toString()
						+ "\n 1: Name\n2: Ingredients\n3: Ingredients Guidance\n4: Method Instructions\n\nSelect field to Update:");
				switch (Utility.takeIntFromScanner()) {
				case 1:
					takeName();
					System.out.println("Name has been updated.");
					break;
				case 2:
					takeIngredients();
					System.out.println("Ingredients has been updated.");
					break;
				case 3:
					takeStringArray("IngredientsGuidance");
					System.out.println("Ingredients Guidance has been updated.");
					break;
				case 4:
					takeStringArray("MethodInstructions");
					System.out.println("Method Instructions has been updated.");
					break;
				default:
					throw new Exception("Invalid Input.");
				}
			}
		} catch (Exception ex) {
			System.out.println("Sorry! There are no " + type + "s saved to be updated.");
		}
	}

	private static Ingredient takeIngredient() {
		try {
			int id = takeID("Ingredient");
			for (Ingredient i : listOfIngredients) {
				if (i.getIngredientID() == id) {
					return i;
				}
			}
			throw new Exception();
		} catch (Exception ex) {
			System.out.println("\nSorry, that ID was Invalid. Please Try Again!");
		}
		return null;
	}

	private static Recipe takeRecipe() {
		try {
			int id = takeID("Recipe");
			for (Recipe r : listOfRecipes) {
				if (r.getRecipeID() == id) {
					return r;
				}
			}
			throw new Exception();
		} catch (Exception ex) {
			System.out.println("\nSorry, that ID was Invalid. Please Try Again!");
		}
		return null;
	}

	private static int takeID(String type) throws Exception {

		while (true) {
			System.out.print("Please enter ID of " + type + ":");
			int id = Utility.takeIntFromScanner();
			if (id >= 0) {
				return id;
			} else {
				System.out.println("\nSorry, that ID was invalid. Please try Again!\n");
			}
		}
	}

	private static String takeName() {
		String name;
		while (true) {
			System.out.print("\nAdding a Name:\nPlease Enter a Name:");
			name = Utility.takeStringFromScanner();
			if (name != "ERROR") {
				return name;
			} else {
				System.out.println("\nSorry, that input was invalid. Please try Again!\n");
			}
		}
	}

	private static FoodType takeFoodType() {
		while (true) {
			System.out.print(
					"\nAdding a Food Type:\n1: Dairy\n2: Cereal\n3: Fruit & Veg\n4: Protein\n5: Sugar\n6: Fat\n7: Composite Food\n8: Spice & Herb\n9: Essential Nutrient\nPlease Enter Selection:");
			int index = Utility.takeIntFromScanner();
			switch (index) {
			case (1):
				return FoodType.DAIRY;
			case (2):
				return FoodType.CEREAL;
			case (3):
				return FoodType.FRUITANDVEG;
			case (4):
				return FoodType.PROTEIN;
			case (5):
				return FoodType.SUGAR;
			case (6):
				return FoodType.FAT;
			case (7):
				return FoodType.COMPOSITEFOOD;
			case (8):
				return FoodType.SPICEANDHERB;
			case (9):
				return FoodType.ESSENTIALNUTRIENT;
			default:
				System.out.println("\nSorry, that input was invalid. Please try Again!\n");
			}
		}
	}

	private static float takeCaloriesPer100Grams() {
		float caloriesPer100Grams;
		while (true) {
			System.out.print("\nAdding the Caloric Details:\nPlease enter the Calories per 100 grams:");
			caloriesPer100Grams = Utility.takeFloatFromScanner();
			if (caloriesPer100Grams != -1) {
				return caloriesPer100Grams;
			} else {
				System.out.println("\nSorry, that input was invalid. Please try Again!\n");
			}
		}
	}

	private static Ingredient[] takeIngredients() {
		while (true) {
			try {
				System.out.print("\nSelecting the Ingredients:\nPlease enter the number of Ingredient Types to Add:");
				amountOfIngredients = Utility.takeIntFromScanner();
				Ingredient[] ingredients = new Ingredient[amountOfIngredients];
				for (int i = 0; i < amountOfIngredients; i++) {
					System.out.println("\n\nIngredient " + i + ":\n");
					ingredients[i] = takeIngredient();
				}
				return ingredients;
			} catch (Exception ex) {
				System.out.println("\nSorry, that Ingredient was invalid. Please try Again!\n");
			}
		}
	}

	private static String[] takeStringArray(String type) {
		while (true) {
			try {
				switch (type) {
				case ("IngredientsGuidance"):
					System.out.println("\nSelecting the Ingredients Guidance:");
					String[] ingredientsGuidance = new String[amountOfIngredients];
					for (int i = 0; i < amountOfIngredients; i++) {
						System.out.println("\n\nIngredient Guidance " + i + ":\n");
						ingredientsGuidance[i] = Utility.takeStringFromScanner();
					}
					return ingredientsGuidance;
				case ("RecipeInstructions"):
					System.out.println("\nSelecting the Recipe Instructions:");
					String[] recipeInstructions = new String[amountOfIngredients];
					for (int i = 0; i < amountOfIngredients; i++) {
						System.out.println("\n\nRecipe Instruction " + i + ":\n");
						recipeInstructions[i] = Utility.takeStringFromScanner();
					}
					return recipeInstructions;
				}
			} catch (Exception ex) {
				System.out.println("\nSorry, that " + type + " was invalid. Please try Again!\n");
			}
		}
	}
}