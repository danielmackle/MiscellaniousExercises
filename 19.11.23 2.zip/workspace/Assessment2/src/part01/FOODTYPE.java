/**
 * @author Daniel Mackle
 * @id 40407187
 * @date 11/11/2023
 */
package part01;

/*
 * Used to hold data which identifies the object as one of a set amount of food types.
 */
public enum FoodType {
	// Enumerated Types
	DAIRY("Dairy"), CEREAL("Cereal"), FRUITANDVEG("Fruit & Veg"), PROTEIN("Protein"), SUGAR("Sugar"), FAT("Fat"),
	COMPOSITEFOOD("Composite Food"), SPICEANDHERB("Spice & Herb"), ESSENTIALNUTRIENT("Essential Nutrient"),
	ERRORNEOUS("Errorneous Food Type");// Used to mark unsuccessful instantiations of FOODTYPE
	// Private Instance Variables

	/**
	 * Holds String associated with the enumerated type
	 */
	private String message;

	// Private Constructor
	/**
	 * Constructor - Saves message input String
	 * 
	 * @param String 'message' - Message correlating to the enumerated type
	 */
	private FoodType(String message) {
		this.message = message;
	}

	// Public Methods
	/**
	 * Returns a String representing the state of the instance
	 * 
	 * @return message tied to enumerated type
	 */
	public String toString() {
		return message;
	}
}