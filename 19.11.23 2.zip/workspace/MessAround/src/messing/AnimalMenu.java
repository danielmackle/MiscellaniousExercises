package messing;

import java.util.ArrayList;
import java.util.Scanner;

public class AnimalMenu {
	private static ArrayList<Animal> heldAnimals = new ArrayList<Animal>();
	public static void main(String[] args) {
		ArrayList<String> optionsTitle = new ArrayList<String>() {
			private static final long serialVersionUID = -4258593211062976611L;
			{
				add("Create Animal");
				add("Display all Animals");
				add("Assign Parents");
				add("Exit");
			}
		};
		ArrayList<MENUOPTION> options = new ArrayList<MENUOPTION>() {
			private static final long serialVersionUID = 5366859239050497889L;
			{
				add(MENUOPTION.NOTEXIT);
				add(MENUOPTION.NOTEXIT);
				add(MENUOPTION.NOTEXIT);
				add(MENUOPTION.EXIT);
			}
		};
		while(true) {
			Menu.displayMenuOptions("Animal Menu", optionsTitle);
			takeSelection(Menu.takeInput(options));
		}
	}
	private static void takeSelection(int selection) {
		switch(selection) {
		case 0:
			//Make new Animal
			makeNewAnimal();
			break;
		case 1:
			//List all Animals
			listAllAnimals(heldAnimals);
			break;
		case 2:
			//Assign parents to an existing animal
			assignParents(heldAnimals);
			break;
		default:
			//Close program
			System.out.println("Thank you! Closing now...");
			System.exit(0);
			break;
		}
	}
	private static void makeNewAnimal() {
		Scanner input = new Scanner(System.in);
		try {
			boolean loop = true;
			Animal animalToMake = new Animal();
			while(loop) {
				System.out.print("\nMaking a new animal.\nPlease enter a name: ");
				animalToMake.setName(input.next());
				System.out.print("\nThank you!\nPlease enter an age: ");
				animalToMake.setAge(Integer.parseInt(input.next()));
				System.out.print("\nThank you!\nPlease enter a Species (0 for Canid, 1 for Feline, 2 for Ursine, 3 for Bovine, or 4 for Other): ");
				animalToMake.setSpecies(SPECIES.parse(Integer.parseInt(input.next())));
				System.out.print("\nThank you!\nPlease enter a Gender (0 for Male, 1 for Female, 2 for Other): ");
				animalToMake.setGender(GENDER.parse(Integer.parseInt(input.next())));
				heldAnimals.add(animalToMake);
				System.out.print("\nThank you! Your animal has been saved:\n"+animalToMake.toString()+"\nIf applicable, you can enter your animal's parents below!\n\n");
				loop=false;
			}
		}
		catch(Exception ex){
			System.out.println("Sorry! Value is invalid. Please try again:");
		}
	}
	private static void listAllAnimals(ArrayList<Animal> heldAnimals) {
		System.out.println("Listing all animals:\n");
		int counter = 0;
		for(Animal selectedAnimal: heldAnimals) {
			System.out.println("Animal "+(++counter)+":\n"+selectedAnimal.toString()+"\n");
		}
	}
	private static void assignParents(ArrayList<Animal> heldAnimals) {
		try {
			System.out.println("Please select child animal:");
			Animal child = findAnimal(heldAnimals);
			int selection = getInt("Please select to assign either a mother(0), father(1), or both(2).");
			switch(selection) {
			case(0):
				System.out.println("Please select mother animal:");
			Animal mother = findAnimal(heldAnimals);
			child.setMother(mother);
			break;
			case(1):
				System.out.println("Please select father animal:");
			Animal father = findAnimal(heldAnimals);
			child.setFather(father);
			break;
			case(2):
				System.out.println("Please select mother animal:");
			Animal bothmother = findAnimal(heldAnimals);
			child.setMother(bothmother);
			System.out.println("Please select father animal:");
			Animal bothfather = findAnimal(heldAnimals);
			child.setFather(bothfather);
			break;
			default:
				System.out.println("Sorry, input is not recognised.");
				break;
			}
		}
		catch(Exception ex) {
			System.out.println("Sorry! Input is invalid.");
		}
	}
	private static Animal findAnimal(ArrayList<Animal> heldAnimals) {
		Scanner input = new Scanner(System.in);
		for(Animal a:heldAnimals) {
			System.out.println("\n"+a.toString());
		}
		System.out.println("Please input the number of the animal:");
		int s = input.nextInt();
		Animal child = heldAnimals.get(s-1);
		return child;
	}
	private static int getInt(String prompt) {
		System.out.print(prompt);
		Scanner input = new Scanner(System.in);
		try {
			System.out.println();
			int output = Integer.parseInt(input.nextLine());
			System.out.println();
			return output;
		}
		catch(Exception ex){
			return -1;
		}
	}
}
