package studentManagement;
public enum GENDER{
	MALE("Male"),
	FEMALE("Female"),
	OTHER("Other"),
	UNDEFINED("Undefined");
	private String input;
	GENDER(String input) {
		this.input = input;
	}
	public String toString() {
		return input;
	}
}