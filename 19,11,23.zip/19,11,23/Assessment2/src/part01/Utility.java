/**
 * @author Daniel Mackle
 * @id 40407187
 * @date 11/11/2023
 */
package part01;

import java.util.Scanner;

/**
 * @summary used to perform common misc. manipulations of data to save lines.
 * @type Abstract Class
 */
abstract class Utility {
	/**
	 * @summary Takes int ID input and validates whether it is valid or invalid. ID
	 *          starts at 0.
	 * @param int 'ID' - Identification integer input
	 * @type Protected Static Class
	 * @implements none
	 * @return boolean - False for pass, True for Fail
	 */
	protected static boolean validatePositiveInt(int ID) {
		try {
			if (ID < 0 | ID > 2147483647) {
				throw new IllegalArgumentException("Integer outside boundaries.");
			}
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
			return false;
		}
		return true;
	}
	protected static boolean validatePositiveFloat(float ID) {
		try {
			if (ID < 0 | ID > 2147483647) {
				throw new IllegalArgumentException("Float outside boundaries.");
			}
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
			return false;
		}
		return true;
	}
	/**
	 * @summary Takes FOODTYPE and validates whether it is erroneous.
	 * @param enum FOODTYPE 'foodtype'
	 * @type Protected Static Class
	 * @implements none
	 * @return boolean - False for pass, True for Fail
	 */
	protected static boolean validateFOODTYPE(FoodType foodType) {
		try {
			if (foodType == FoodType.ERRORNEOUS) {
				throw new IllegalArgumentException(foodType.toString());
			}
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @summary Takes String input and validates whether it is erroneous.
	 * @param String 'string'
	 * @type Protected Static Class
	 * @implements none
	 * @return boolean - False for pass, True for Fail
	 */
	protected static boolean validateString(String stringToValidate) {
		try {
			if (stringToValidate == "") {
				throw new IllegalArgumentException("String is Null");
			}
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @summary Takes String Array and outputs as a single String.
	 * @param String[] 'stringArray'
	 * @type Protected Static Class
	 * @implements none
	 * @return String - String output representing all Strings in the Array
	 */
	protected static String stringArrayToString(String[] stringArray) {
		String response = "";
		for (String string : stringArray) {
			response += string;
		}
		return response;
	}

	/**
	 * @summary Takes Object Array input and and outputs as a single String
	 *          representation.
	 * @param Ingredient[] 'ingredientArray'
	 * @type Protected Static Class
	 * @implements none
	 * @return boolean - False for pass, True for Fail
	 */
	protected static String objectArrayToString(Object[] objectArray) {
		String response = "";
		for (Object object : objectArray) {
			response += object.toString();
		}
		return response;
	}

	/**
	 * @summary Takes 2DArray input and and outputs as a single String
	 *          representation.
	 * @param Ingredient[] 'ingredientArray'
	 * @type Protected Static Class
	 * @implements none
	 * @return boolean - False for pass, True for Fail
	 */
	protected static String recipe2DArrayToString(Recipe[][] recipe2DArray) {
		String response = "";
		for (Recipe[] recipe1DArray : recipe2DArray) {
			for (Recipe recipe : recipe1DArray) {
				response += recipe.toString();
			}
		}
		return response;
	}

	protected static Scanner input = new Scanner(System.in);

	protected static String takeStringFromScanner() {
		try {
			return (String) input.next();
		} catch (Exception exception) {
			return "ERROR";
		}
	}

	protected static int takeIntFromScanner() {
		try {
			return Integer.parseInt(input.next());
		} catch (Exception exception) {
			return -1;
		}
	}
	protected static float takeFloatFromScanner() {
		try {
			return Float.parseFloat(input.next());
		} catch (Exception exception) {
			return -1;
		}
	}
	protected static boolean isObjectNull(Object toValidate) {
		if(toValidate != null) {
			return false;
		}
		return true;
	}
	protected static void Exit() {
		System.out.println("\n");
		System.out.println("Happy to help! Closing now.");
		System.exit(0);
	}
}