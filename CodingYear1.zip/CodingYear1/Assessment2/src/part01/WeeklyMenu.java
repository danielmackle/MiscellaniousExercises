package part01;

public class WeeklyMenu {

}
