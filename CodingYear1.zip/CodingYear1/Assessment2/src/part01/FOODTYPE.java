/**
 * @author Daniel Mackle
 * @id 40407187
 * @date 11/11/2023
 */
package part01;
/**
 * @summary used to hold data which identifies the object as one of a set amount of food types.
 * @type Public Enumerated Class
 */
public enum FOODTYPE 
{
	//Enumerated Types
	ERRORNEOUS("Errorneous Food Type");//Used to mark unsucessful instantiations of FOODTYPE
	//Private Instance Variables
	/**
	 * @reference message
	 * @summary holds String associated with the enumerated type
	 */
	private String message;
	//Private Constructor
	/**
	 * @summary Constructor - Saves message input String
	 * @param int 'message' - Message correlating to the enumerated type
	 */
	private FOODTYPE(String message) 
	{
		this.message = message;
	}
	//Public Methods
	/**
	 * @summary Returns a String representing the state of the instance
	 * @type Public Method
	 * @return String - message tied to enumerated type
	 */
	public String toString() 
	{
		return message;
	}
}