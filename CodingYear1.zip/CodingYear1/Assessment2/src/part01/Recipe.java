/**
 * @author Daniel Mackle
 * @id 40407187
 * @date 12/11/2023
 */
package part01;
/**
 * @summary holds data of a specific recipe. Only holds data, does not manipulate data.
 * @type Public Class
 */
public class Recipe 
{
	private int recipeID;
	private String recipeName;
	private Ingredient[] ingredients;
	private String[] ingredientsGuidance;
	private String[] methodInstructions;
	private static int nextRecipeID = 0;
	public int getRecipeID() 
	{
		return this.recipeID;
	}
	public int getNextRecipeID() 
	{
		return nextRecipeID++;
	}
	public String getRecipeName() 
	{
		return this.recipeName;
	}
	public Ingredient[] getIngredientsAsString() 
	{
		//todo
		return this.ingredients;
	}
	public String[] getIngredientsGuidanceAsString()
	{
		//todo
		return this.ingredientsGuidance;
	}
	public String[] getMethodInstructionsAsString()
	{
		//todo
		return this.methodInstructions;
	}
	public void setRecipeID(int recipeID) 
	{
		this.recipeID = recipeID;
	}
	public void setRecipeName(String recipeName) 
	{
		this.recipeName = recipeName;
	}
	public void setIngredients(Ingredient[] ingredients) 
	{
		this.ingredients = ingredients;
	}
	public void setIngredientsGuidance(String[] ingredientsGuidance) 
	{
		this.ingredientsGuidance = ingredientsGuidance;
	}
	public void setMethodInstructions(String[] methodInstructions) 
	{
		this.methodInstructions = methodInstructions;
	}
	public Recipe(){}
	public Recipe(String recipeName,Ingredient[] ingredients,String[] ingredientsGuidance, String[] methodInstrucutions) 
	{
		setRecipeID(getNextRecipeID());
		setRecipeName(recipeName);
		setIngredients(ingredients);
		setIngredientsGuidance(ingredientsGuidance);
		setMethodInstructions(methodInstructions);
	}
	public String toString() {
		return "Recipe ID:"+this.getRecipeID()+"\nRecipe Name: "+this.getRecipeName()+"\nIngredients: "+this.getIngredientsAsString()+"\nGuidance for Ingredients: "+this.getIngredientsGuidanceAsString()+"\nMethod: "+this.getMethodInstructionsAsString();
	}
}
