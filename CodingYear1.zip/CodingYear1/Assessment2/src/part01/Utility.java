/**
 * @author Daniel Mackle
 * @id 40407187
 * @date 11/11/2023
 */
package part01;
/**
 * @summary used to perform common misc. manipulations of data to save lines.
 * @type Abstract Class
 */
abstract class Utility {
	/**
	 * @summary Takes int ID input and validates whether it is valid or invalid. ID starts at 0.
	 * @param int 'ID' - Identification integer input
	 * @type Protected Static Class
	 * @implements none
	 * @return boolean - False for pass, True for Fail
	 */
	protected static boolean validateID(int ID){
		try 
		{
			if(ID <= 0 | ID > 2147483647) 
			{
				throw new IllegalArgumentException("ID less than 0.");
			}
		}
		catch(Exception exception) 
		{
			System.out.println(exception.getMessage());
			return false;
		}
		return true;
	}
	/**
	 * @summary Takes FOODTYPE and validates whether it is errorneous.
	 * @param enum FOODTYPE 'foodtype'
	 * @type Protected Static Class
	 * @implements none
	 * @return boolean - False for pass, True for Fail
	 */
	protected static boolean validateFOODTYPE(FOODTYPE foodType) {
		try 
		{
			if(foodType == FOODTYPE.ERRORNEOUS) 
			{
				throw new IllegalArgumentException(foodType.toString());
			}
		}
		catch(Exception exception) 
		{
			System.out.println(exception.getMessage());
			return false;
		}
		return true;
	}
	/**
	 * @summary Takes int input and validates whether it is errorneous.
	 * @param int 'amountHeld'
	 * @type Protected Static Class
	 * @implements none
	 * @return boolean - False for pass, True for Fail
	 */
	protected static boolean validateAmountHeld(int amountHeld) {
		try 
		{
			if(amountHeld <= 1) 
			{
				throw new IllegalArgumentException("Amount Held Below 0");
			}
		}
		catch(Exception exception) 
		{
			System.out.println(exception.getMessage());
			return false;
		}
		return true;
	}
}