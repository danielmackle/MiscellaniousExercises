/**
 * @author Daniel Mackle
 * @id 40407187
 * @date 11/11/2023
 */
package part01;
/**
 * @summary holds data of a specific type of ingredient. Only holds data, does not manipulate data.
 * @type Public Class
 * @dependency part01.Utility
 */
public class Ingredient 
{
	//Private Instance Variables
	/**
	 * @reference ingredientID
	 * @summary holds the unique ID of the ingredient 
	 */
	private int ingredientID;
	/**
	 * @reference foodType
	 * @summary holds the enum foodtype of the ingredient
	 */
	private FOODTYPE foodType;
	/**
	 * @reference amountHeld
	 * @summary holds the integer amount of the ingredient in a recipe
	 */
	private int amountHeld;
	/**
	 * @reference caloriesPer100Grams
	 * @summary holds the floating point value for the caloric energy of the ingredient per 100 grams
	 */
	private float caloriesPer100Grams;
	//Private Class Variables
	//holds the number of the ID of the next instance. Is appreciated upon successful instantiation.
	private static int nextIngredientID=0;
	//Public Constructors
	/**
	 * @summary Empty Constructor
	 */
	public Ingredient() {}
	//Private Constructor
	/**
	 * @summary Constructor - Saves full data of Object
	 * @param int 'message' - Message correlating to the enumerated type
	 */
	public Ingredient(FOODTYPE foodType, int amountHeld, float caloriesPer100Grams) 
	{
		try 
		{
			setIngredientID(nextIngredientID++);
			setFoodType(foodType);
			setAmountHeld(amountHeld);
			setCaloriesPer100Grams(caloriesPer100Grams);
		}
		catch(Exception exception)
		{
			//Failure in Construction - Set Warning Values
			this.ingredientID = -1;
			this.foodType = FOODTYPE.ERRORNEOUS;
			this.amountHeld = -1;
			this.caloriesPer100Grams = -1;
		}
	}
	//Public Methods
	/**
	 * @reference getIngredientID
	 * @summary accessor
	 * @return integer ingredientID
	 */
	public int getIngredientID() 
	{
		return this.ingredientID;
	}
	/**
	 * @reference getFoodType
	 * @summary accessor
	 * @return integer foodType
	 */
	public FOODTYPE getFoodType() 
	{
		return this.foodType;
	}
	/**
	 * @reference getAmountHeld
	 * @summary accessor
	 * @return integer amountHeld
	 */
	public int getAmountHeld()
	{
		return this.amountHeld;
	}
	/**
	 * @reference getCaloriesPer100Grams
	 * @summary accessor
	 * @return float caloriesPer100Grams
	 */
	public float getCaloriesPer100Grams()
	{
		return this.caloriesPer100Grams;
	}
	/**
	 * @reference setIngredientID
	 * @summary mutator - checks validation with Util
	 * @dependency Util
	 * @param ingredientID - new IngredientID
	 * @throws Exception 
	 */
	public void setIngredientID(int ingredientID) 
			throws Exception 
	{
		if(Utility.validateID(ingredientID)) 
		{
			throw new Exception();
		}
		this.ingredientID = ingredientID;
	}
	/**
	 * @reference setFoodType
	 * @summary mutator - checks validation with Util
	 * @dependency Util
	 * @param foodType - new foodType
	 * @throws Exception 
	 */
	public void setFoodType(FOODTYPE foodType) 
			throws Exception 
	{
		if(Utility.validateFOODTYPE(foodType)) 
		{
			throw new Exception();
		}
		this.foodType = foodType;
	}
	/**
	 * @reference setAmountHeld
	 * @summary mutator - checks validation with Util
	 * @dependency Util
	 * @param amountHeld - new amountHeld
	 * @throws Exception 
	 */
	public void setAmountHeld(int amountHeld) 
			throws Exception
	{
		if(Utility.validateAmountHeld(amountHeld)) 
		{
			throw new Exception();
		}
		this.amountHeld = amountHeld;
	}
	/**
	 * @reference caloriesPer100Grams
	 * @summary mutator - checks validation with Util
	 * @dependency Util
	 * @param caloriesPer100Grams - new caloriesPer100Grams
	 * @throws Exception 
	 */
	public void setCaloriesPer100Grams(float caloriesPer100Grams) 
			throws Exception
	{
		if(Utility.validateAmountHeld(amountHeld)) 
		{
			throw new Exception();
		}
		this.caloriesPer100Grams = caloriesPer100Grams;
	}
	public String toString() {
		return "Ingredient ID:"+this.getIngredientID()+"\nFood Type: "+this.getFoodType()+"\nAmount Held: "+this.getAmountHeld()+"\nCalories Per 100 Grams: "+this.getCaloriesPer100Grams();
	}
}