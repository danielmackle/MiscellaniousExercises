package messing;

public enum MENUOPTION {
	NOTEXIT,
	EXIT
}