package messing;

public class Animal {
	//Class Variables
	/**
	 * held details to be accessed
	 */
	private SPECIES species;
	private GENDER gender;
	private String name;
	private int age;
	private Animal mother;
	private Animal father;
	
	//Public Class Properties
	public SPECIES getSpecies() {
		return species;
	}
	public void setSpecies(SPECIES species) {
		this.species = species;
	}
	public GENDER getGender() {
		return gender;
	}
	public void setGender(GENDER gender) {
		this.gender = gender;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Animal getMother() {
		return mother;
	}
	public void setMother(Animal mother) {
		this.mother = mother;
	}
	public Animal getFather() {
		return father;
	}
	public void setFather(Animal father){
		this.father = father;
	}
	
	/**
	 * Null constructor
	 * Sets the class variables to their default values
	 * @throws Exception 
	 */
	public Animal() throws Exception{
		setSpecies(SPECIES.UNDEFINED);
		setGender(GENDER.UNDEFINED);
		setName(null);
		setAge(-1);
		setMother(null);
		setFather(null);
	}
	/**
	 * Constructor for all params
	 * @param name = String; name of animal
	 * @param age = int; age of animal
	 * @param mother = Animal(); class linked to animal as mother
	 * @param father = Animal(); class linked to animal as father
	 * @param species = String; species of animal 
	 * @param gender = Gender.; enum gender of animal
	 * @throws Exception 
	 */
	public Animal(String name, int age, Animal mother, Animal father,SPECIES species,GENDER gender) throws Exception{
		setSpecies(species);
		setGender(gender);
		setName(name);
		setAge(age);
		setMother(mother);
		setFather(father);
	}
	
	//Public Class Methods
	/**
	 * Outputs the details of the animal instance as a string
	 */
	public String toString() {
		String name = this.getName();
		GENDER gender = this.getGender();
		SPECIES species = this.getSpecies();
		int age = this.getAge();
		String mother = "none";
		String father = "none";
		try {mother = this.getMother().name;
		}catch(Exception ex) {}
		try {father = this.getFather().name;
		}catch(Exception ex) {}
		return "Name:"+name+"\nGender:"+gender+"\nSpecies:"+species+"\nAge:"+age+"\nMother:"+mother+"\nFather:"+father;
	}
}
