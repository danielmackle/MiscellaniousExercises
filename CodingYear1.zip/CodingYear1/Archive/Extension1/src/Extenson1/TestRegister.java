package Extenson1;
import java.util.Scanner;
public class TestRegister {
	public static SalesRegister sr = new SalesRegister();
	public static void main(String[] args) {
		while(true) {
			switch(Menu()) {
			case 1:
				CashSale();
				System.out.println("Cash Sale Successful!\n");
				break;
			case 2:
				CardSale();
				System.out.println("Card Sale Successful!\n");
				break;
			case 3:
				DisplayTransactions();
				break;
			case 4:
				System.exit(0);
				System.out.println("Goodbye!\n");
				break;
			}
		}
	}
	private static void DisplayTransactions() {
		System.out.println("\nTransactions:\n"+sr.getTransactions());
	}
	private static void CashSale() {
		Scanner s = new Scanner(System.in);
		System.out.print("\nEnter Item Name: ");
		String itemName = s.nextLine();
		System.out.print("\nEnter price in £: ");
		double price = s.nextDouble();
		System.out.print("\nEnter Amount: ");
		int amount = s.nextInt();
		sr.cashSale(itemName, amount*price);
		//s.close();
	}
	private static void CardSale() {
		Scanner s = new Scanner(System.in);
		System.out.print("\nEnter Item Name: ");
		String itemName = s.nextLine();
		System.out.print("\nEnter price in £: ");
		double price = s.nextDouble();
		System.out.print("\nEnter Amount: ");
		int amount = s.nextInt();
		sr.cardSale(itemName, amount*price);
		//s.close();
	}
	private static int Menu() {
		System.out.println("\nSales Register\n**************\n1. Cash Sale\n2. Card Sale\n3. Display Transactions\n4. Quit\n\nEnter Selection: ");
		Scanner s = new Scanner(System.in);
		String inputs = s.next();
		int input = Integer.parseInt(inputs);
		//s.close();
		return input;
	}
}