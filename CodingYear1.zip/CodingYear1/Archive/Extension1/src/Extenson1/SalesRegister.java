package Extenson1;
public class SalesRegister {
	private double totalValue; // total value of transactions
	public double getTotalValue() {
		return totalValue;
	}
	public void setTotalValue(double newValue) {
		totalValue = newValue;
	}
	
	private String transactions; // list of transactions
	public String getTransactions() {
		return transactions;
	}
	public void setTransactions(String newTransactions) {
		transactions = newTransactions;
	}
	
	private int numCardSales; // number of card sales
	public int getNumCardSales() {
		return numCardSales;
	}
	public void setNumCardSales(int newNumCardSales) {
		numCardSales = newNumCardSales;
	}
	
	private int numCashSales; // number of cash sales
	public double getNumCashSales() {
		return numCashSales;
	}
	public void setNumCashSales(int newNumCashSales) {
		numCashSales = newNumCashSales;
	}
	public SalesRegister() {
		totalValue = 0.0;
		numCardSales = 0;
		numCashSales = 0;
		transactions = "";
	}
	public void cashSale(String item, double value) {
		if(item != "" && value!= 0) {
			totalValue += value;
			numCashSales++;
			transactions+="Card:£"+value+"\t"+item+"\n";
		}
	}
	public void cardSale(String item, double value) {
		if(item != "" && value!= 0) {
			totalValue += value;
			numCardSales++;
			transactions+="Card:£"+value+"\t"+item;
		}
	}
	public String listTransactions() {
		return transactions;
	}
}
