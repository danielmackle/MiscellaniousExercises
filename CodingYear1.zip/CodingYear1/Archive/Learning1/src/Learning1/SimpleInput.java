package Learning1;

import java.util.Scanner;

public class SimpleInput 
{
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter your name: ");
		String name = input.nextLine();
		System.out.println("Hello " + name + ", welcome to QUB!");
		
		input.close();
	}
}