package Learning1;

import java.util.Scanner;

public class Vowels 
{
	public static void main(String args[]) 
	{
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter a letter: ");
		String str = input.nextLine();
		char letter = str.charAt(0);
		
		input.close();
		
		switch (letter) 
		{
			case 'a':
			case 'e':
			case 'i':
			case 'o':
			case 'u':
			System.out.println("Letter is a vowel: " + letter);
			break;
			default:
			System.out.println("Letter is not a vowel: " + letter);
		}
	}
}