package exercises;
import java.util.Scanner;
public class asteriskBox {
	public static void main(String[] args) 
	{
		Scanner s = new Scanner(System.in);
		String input = "";
		String output="";

		System.out.print("Please enter your Name: ");
		input = s.next();
		s.close();

		byte holdLen = (byte)(input.length()+2);
		output = appendStar(holdLen,output);

		output+="\n*";

		output+= input;

		output+="*\n";

		output = appendStar(holdLen,output);

		System.out.print(output);
	}
	private static String appendStar(byte holdLen, String input) {
		for(int i=0; i<holdLen; i++) {
			input+="*";
		}
		return input;
	}
}
