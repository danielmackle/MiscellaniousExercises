package exercises;

public class bigCow {
	public static void main(String[] args) 
	{
		bigM();
		for(int i=0; i<5; i++) {
			bigO();
		}
	}
	private static void bigM() {
		System.out.print("M       M\nMM     MM\nM M   M M\nM  M  M M\nM   M   M\n");
	}
	private static void bigO() {
		System.out.print("   OOO   \n OO   OO \nOO     OO\n OO   OO \n   OOO   \n");
	}
}
