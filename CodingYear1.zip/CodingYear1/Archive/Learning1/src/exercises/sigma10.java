package exercises;

public class sigma10 {
	public static void main(String[] args) 
	{
		byte acc=0;
		for (byte i =0;i<=10;i++) {
			acc+=i;
		}
		System.out.print(acc);
	}
}
