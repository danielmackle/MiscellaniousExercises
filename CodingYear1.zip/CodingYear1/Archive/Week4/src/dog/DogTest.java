package dog;
import java.util.Scanner;
public class DogTest {
	static final int MAX = 10;
	static final String PROMPT = "---->";
	static final String SPACES = " ";
	static final String options[] = {"Add new Dog", "Display details for a Dog",
			"Update details for a Dog", "List all Dogs", "Delete all Dogs",
			"Delete one Dog", "Quit"};
	static final int QUIT = options.length;
	static Dog pets[] = new Dog[MAX];
	static int count = 0;
	static String title = "Dog Manager";
	static Menu myMenu = new Menu(title, options);

	public static void main(String[] args) {
		int choice;
		do {
			choice = myMenu.getUserChoice();
			if (choice != QUIT) {
				processChoice(choice);
			}
		}
		while( choice != QUIT );
		System.out.println("\nGoodbye!");
	}
	private static void processChoice(int choice) {
		switch(choice) {
		case 1 : addNewDog();
		break;
		case 2 : displayDogDetails();
		break;
		case 3 : updateDogDetails();
		break;
		case 4 : listAllDogs();
		break;
		case 5 : deleteAllDogs();
		break;
		case 6 : deleteOneDog();
		break;
		default: System.out.println("Option "+choice+" is invalid.");
		}
		System.out.println();
	}
	private static void deleteAllDogs() {
		System.out.println("\nOK - Deleting all dogs.");
		if (count == 0) {
			System.out.println(PROMPT+"Sorry, there are no dogs.");
		}
		else {
			System.out.println("Deleted following Dogs:");
			for(int index=0; index<count;index++) {
				System.out.println(SPACES+(index+1)+". " + pets[index].getName());
				pets[index] = null;
			}
			pets = null;
		}
		System.out.println();
	}
	private static void deleteOneDog() {
		try {
			Dog heldDog = findDog();
			System.out.println("Deleting: " + heldDog.getName());
			int deleteIndex = findDogIndex(heldDog.getName());
			if(deleteIndex != -1) {
				pets[deleteIndex]=null;
			}
			else {
				System.out.println("Sorry! Dog could not be deleted.");
			}
		}
		catch(Exception ex) {
			System.out.println("Sorry! Dog could not be deleted.");
		}
	}
	private static void addNewDog() {
		try {
			Scanner input = new Scanner(System.in);
			if ( count < MAX ) {
				System.out.println("\nOK - Add a new Dog.");
				Dog dg = new Dog();
				System.out.print(PROMPT + "Enter name: ");
				String name = input.nextLine();
				dg.setName(name);
				System.out.print(PROMPT + "Enter breed: ");
				String breed = input.nextLine();
				dg.setBreed(breed);
				System.out.print(PROMPT + "Enter age: ");
				int age = input.nextInt();
				dg.setAge(age);
				input.nextLine();
				System.out.print(PROMPT + "Enter gender (1 for Male 2 for Female): ");
				int gen = input.nextInt();
				input.nextLine();
				if(gen == 1) {
					dg.setGender(Gender.MALE);
				}
				else if (gen == 2) {
					dg.setGender(Gender.FEMALE);
				}
				else {
					dg.setGender(Gender.UNASSIGNED);
				}
				pets[count] = dg;
				count++;
			}
			else {
				System.out.println("No room to add and more dogs!");
			}
		}
		catch(Exception ex) {
			System.out.println("Sorry! Could not add the dog. Please try again!");
		}
	}
	private static void listAllDogs() {
		System.out.println("\nOK - List all dogs.");
		if (count == 0) {
			System.out.println(PROMPT+"Sorry, there are no dogs.");
		}
		else {
			System.out.println("We have the following Dogs:");
			for(int index=0; index<count;index++) {
				System.out.println(SPACES+(index+1)+". " + pets[index].getName());
			}
		}
		System.out.println();
	}
	private static void displayDogDetails() {
		Dog heldDog = findDog();
		System.out.println("Dog's Details: \n"+heldDog.toString());
	}
	public static void updateDogDetails() {
		Dog heldDog = findDog();
		System.out.println("Dog's Details: \n"+heldDog.toString());
		System.out.println("Which detail would you like to change?\nPlease press:\n1 for Name\n2 for Breed\n3 for Age\n4 for Gender");
		Scanner s = new Scanner(System.in);
		int input = s.nextInt();
		switch(input) {
		case 1:{
			System.out.print("Please enter new name: ");
			String strInput = s.next();
			heldDog.setName(strInput);
			break;
		}
		case 2:{
			System.out.print("Please enter new breed: ");
			String strInput = s.next();
			heldDog.setBreed(strInput);
			break;
		}
		case 3:{
			System.out.print("Please enter new age: ");
			int intInput = s.nextInt();
			heldDog.setAge(intInput);
			break;
		}
		case 4:{
			System.out.print("Please enter new gender (1 for male, 2 for female): ");
			int intInput = s.nextInt();
			if(intInput == 1) {
				heldDog.setGender(Gender.MALE);
			}
			else if(intInput == 2) {
				heldDog.setGender(Gender.FEMALE);
			}
			else {
				heldDog.setGender(Gender.UNASSIGNED);
			}
			break;
		}
		}
		System.out.println();
	}
	private static Dog findDog() {
		try {
			if (count == 0) {
				System.out.println(PROMPT+"Sorry, there are no dogs.");
				return new Dog();
			}
			else {
				System.out.println("We have the following Dogs:");
				for(int index=0; index<count;index++) {
					System.out.println(SPACES+(index+1)+". " + pets[index].getName());
				}
			}
			System.out.println("Please input the dog's numbber");
			Scanner s = new Scanner(System.in);
			int input = s.nextInt();
			System.out.println();
			Dog heldDog = pets[input-1];
			return heldDog;}
		catch(Exception ex){
			System.out.println(PROMPT+"Sorry, there are no dogs.");
			return new Dog();
		}
	}
	private static int findDogIndex(String dogName) {
		for(int i=0; i<pets.length; i++) {
			if(dogName == pets[i].getName()) {
				return i;
			}
		}
		return -1;
	}
}
