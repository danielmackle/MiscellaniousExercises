package dog;

public enum Gender {
	MALE("Male"), FEMALE("Female"), UNASSIGNED("Unknown");
	
	private String genStr;
	
	private Gender(String genStr) {
		this.genStr = genStr;
	}
}
