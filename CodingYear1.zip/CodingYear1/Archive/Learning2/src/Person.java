public class Person {
	private String name;
	private String city;
	private int age;
	private double height;
	public String getDetails() {
		return "Name: "+ name + ", City: "+city +
				", Age: "+age + ", Height: "+height;
	}
	public void setAge(int age) {
		if ( age > this.age ) {
			this.age = age;
		}
	}
	public int getAge() {
		return age;
	}
	public Person(String name, String city, int age, double height) {
		this.name = name;
		this.city = city;
		this.age = age;
		this.height = height;
	}
}
