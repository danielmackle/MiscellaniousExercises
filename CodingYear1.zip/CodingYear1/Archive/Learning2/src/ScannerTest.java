import java.util.Scanner;
public class ScannerTest {
	static Scanner input;
	public static void main(String[] args) {
		input = new Scanner(System.in);
		String name; // name of a person
		String city; // location of a person
		int age; // age a person
		double height; // height (in metres) of a person
		for(int i=0; i<5; i++)
		{
			// Read in some data for a person
			System.out.print("Enter name: ");
			name = input.nextLine(); // will read as a line of text
			System.out.print("Enter city: ");
			city = input.nextLine();
			System.out.print("Enter age: ");
			age = input.nextInt();
			System.out.print("Enter height (in metres): ");
			height = input.nextDouble();
			// output data
			System.out.println();
			System.out.println("Name: "+name);
			System.out.println("City: "+city);
			System.out.println("Age: "+age);
			System.out.println("Height: "+height);
		}
		input.close();
	}
}