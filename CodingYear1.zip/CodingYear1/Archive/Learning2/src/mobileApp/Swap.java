package mobileApp;

public class Swap {

	public static void main(String[] args) {
		int first = 3;
		int second = 4;
		System.out.println("First variable: "+first+" Second Variable: "+second);
		int hold=0;
		hold=first;
		first = second;
		second = hold;
		System.out.println("First variable: "+first+" Second variable: " + second);
	}

}
