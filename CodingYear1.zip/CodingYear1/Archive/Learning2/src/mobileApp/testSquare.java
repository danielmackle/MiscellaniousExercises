package mobileApp;

public class testSquare {
	public static void main(String[] args) {
		//entry point
		final int LENGTH = 5;
		square s = new square(LENGTH);
		System.out.print(s.getArea());
	}
}
