package mobileApp;

public class Student {
	private String name;
	private int noOfExams;
	private double totalMark;
	public String getName() {
		return name;
	}
	public Student(String name) {
		this.name = name;
		this.noOfExams=0;
		this.totalMark=0;
	}
	public void addMark(int totalMark) {
		this.totalMark+= totalMark;
		++this.noOfExams;
	}
	public void removeMark(int totalMark) {
		this.totalMark-= totalMark;
		--this.noOfExams;
	}
	public double getTotalMark() {
		return this.totalMark;
	}
	public double getAverageMark() {
		return this.totalMark/this.noOfExams;
	}
}
