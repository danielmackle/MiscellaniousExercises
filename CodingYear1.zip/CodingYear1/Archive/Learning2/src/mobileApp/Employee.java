package mobileApp;

public class Employee {
	private String employeeName;
	private double currentSalary;
	public Employee(String employeeName, double currentSalary)
	{
		setEmployeeName(employeeName);
		setCurrentSalary(currentSalary);
	}
	public String getEmployeeName(){
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getCurrentSalary(){
		return currentSalary;
	}
	public void setCurrentSalary(double currentSalary) {
		this.currentSalary = currentSalary;
	}
	public void raiseSalary(double factor) {
		setCurrentSalary(currentSalary*factor);
	}
	
}