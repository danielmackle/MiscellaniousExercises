package mobileApp;

public class FarenheitToCelsius {
	public static void main(String[] args) {
		final double INPUT = 20;
		double answer = (9/5)*INPUT+32;
		System.out.println("The Fahrenheit equivalent of 20 degrees Celsius is: "+answer);
	}
}
