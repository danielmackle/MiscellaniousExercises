package mobileApp;

public class employeeTester {
	public static void main(String[] args) {
		Employee e = new Employee("Daniel",20.0);
		e.raiseSalary(2);
		System.out.print(e.getCurrentSalary());
	}
}
