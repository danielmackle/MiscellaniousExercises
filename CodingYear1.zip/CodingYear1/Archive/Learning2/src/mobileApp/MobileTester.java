package mobileApp;

public class MobileTester {
	public static void main(String[] args) {
		Mobile jimMobile = new Mobile("PAYG", "iPhone 7", "07712442442");
		System.out.println("Account type: " + jimMobile.getAccType());
		System.out.println("Device : " + jimMobile.getDevice());
		System.out.println("Number : " + jimMobile.getNumber());
		System.out.println("Balance : " + jimMobile.getBalance());
		jimMobile.addCredit(10.00);
		System.out.println("\nCredit Successful for \n Number: " + jimMobile.getNumber()
		+ "\n Balance: " + jimMobile.getBalance());
		jimMobile.makeCall(15);
		System.out.println("\nCall made for \n Number: " + jimMobile.getNumber()
		+ "\n Balance: " + jimMobile.getBalance());
		jimMobile.sendText(2);
		System.out.println("\nText sent for \n Number: " + jimMobile.getNumber()
		+ "\n Balance: " + jimMobile.getBalance());
		Mobile daniel = new Mobile("Credit", "Nokia", "45454545497");
	}
}