package mobileApp;

public class Animal {
	public Animal() {}
	public Animal(String name, String gender, double height, double age, double weight) {
		this.setName(name);
		this.setGender(gender);
		this.setAge(age);
		this.setHeight(height);
		this.setWeight(weight);
	}
	
	private String name;
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	private String gender;
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getGender() {
		return this.gender;
	}
	
	private double height;
	public double getHeight() {
		return this.height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public void alterHeight(double alter) {
		this.setHeight(this.getHeight()+alter);
	}
	
	private double age;
	public double getAge() {
		return this.age;
	}
	public void setAge(double age) {
		this.age = age;
	}
	public void alterAge(double alter) {
		this.setAge(this.getAge()+alter);
	}
	
	private double weight;
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public double getWeight() {
		return this.weight;
	}
	public void alterWeight(double alter) {
		this.setWeight(this.getWeight()+alter);
	}
}
