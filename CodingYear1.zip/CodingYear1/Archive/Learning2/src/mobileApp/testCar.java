package mobileApp;

public class testCar {
	public static void main(String[] args) {
		Car myCar = new Car(1,20,20);
		myCar.drive(5);
		System.out.print(myCar.getCurrentFuel()+"\n");
		fuelFullTank(myCar);
	}
	private static void fuelFullTank(Car carToFill) {
		double fuelToFill = (carToFill.getTankCapacity()-carToFill.getCurrentFuel());
		carToFill.setCurrentFuel(carToFill.getTankCapacity());
		System.out.print("Cost is: "+(1.288*4.546)*fuelToFill);
	}
}
