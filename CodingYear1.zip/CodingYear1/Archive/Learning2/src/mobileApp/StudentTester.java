package mobileApp;

public class StudentTester {
	public static void main(String[] args) {
		Student daniel = new Student("Daniel");
		daniel.addMark(100);
		daniel.addMark(50);
		System.out.println(daniel.getTotalMark());
		System.out.println(daniel.getAverageMark());
		daniel.removeMark(100);
		System.out.println(daniel.getTotalMark());
		System.out.println(daniel.getAverageMark());
	}
}
