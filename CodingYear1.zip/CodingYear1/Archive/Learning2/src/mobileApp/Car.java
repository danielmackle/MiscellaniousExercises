package mobileApp;

public class Car {
	private double fuelEfficiency; //mpg
	public double getFuelEfficiency() {
		return fuelEfficiency;
	}
	public void setFuelEfficiency(double fuelEfficiency) {
		this.fuelEfficiency = fuelEfficiency;
	}
	private double currentFuel; //gallons
	public double getCurrentFuel() {
		return currentFuel;
	}
	public void setCurrentFuel(double currentFuel) {
		this.currentFuel = currentFuel;
	}
	private double tankCapacity; //gallons
	public double getTankCapacity() {
		return tankCapacity;
	}
	public void setTankCapacity(double tankCapacity) {
		this.tankCapacity = tankCapacity;
	}
	public void drive(double distance) {
		setCurrentFuel(currentFuel - (fuelEfficiency*distance));
	}
	public Car(double fuelEfficiency, double currentFuel, double tankCapacity){
		setFuelEfficiency(fuelEfficiency);
		setCurrentFuel(currentFuel);
		setTankCapacity(tankCapacity);
	}
}
