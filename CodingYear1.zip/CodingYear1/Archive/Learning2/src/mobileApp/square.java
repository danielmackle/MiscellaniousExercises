package mobileApp;

public class square {
	private int sideLength;
	private int area;
	public square(int sideLength) {
		this.sideLength = sideLength;
		area = sideLength * sideLength;
	}
	public int getArea() { return area; }
	public void grow() { 
		sideLength = 2 * sideLength; 
		area = getArea();
	}
}