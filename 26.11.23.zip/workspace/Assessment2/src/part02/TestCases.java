package part02;

import part01.*;
public class TestCases extends QUBKitchen{
	public static void main(String[] args) {
		testCase1();
	}
	public static void testCaseStart(int numbered, String group, String desc) {
		System.out.println("Test Case: "+numbered+"\nDescription:"+desc+"\n#########START TEST CASE#########");
	}
	public static void testCaseEnd() {
		System.out.println("#########END TEST CASE#########");
	}
	public static void testCase1() {
		try {
			testCaseStart(1,"Ingredient Management","Adding an ingredient with all valid values.");
			System.out.println("Input: Name-Beef FoodType-FoodType.PROTEIN CaloriesPer100Grams-120");
			Ingredient toAdd = new Ingredient("Beef", FoodType.PROTEIN,120);
			listOfIngredients.add(toAdd);
			System.out.println("Output:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		}
		catch(Exception ex){
			System.out.println("Test Failed - Exception Unhandled");
			ex.printStackTrace();
		}
	}
	public static void testCase2() {
		try {
			testCaseStart(2,"Ingredient Management","Adding an ingredient with null name.");
			System.out.println("Input: Name-null FoodType-FoodType.PROTEIN CaloriesPer100Grams-120");
			Ingredient toAdd = new Ingredient(null, FoodType.PROTEIN,120);
			listOfIngredients.add(toAdd);
			System.out.println("Output:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		}
		catch(Exception ex){
			System.out.println("Test Failed - Exception Unhandled");
			ex.printStackTrace();
		}
	}
	public static void testCase3() {
		try {
			testCaseStart(3,"Ingredient Management","Adding an ingredient with extremely long name.");
			System.out.println("Input: Name-eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee FoodType-FoodType.PROTEIN CaloriesPer100Grams-120");
			Ingredient toAdd = new Ingredient("eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", FoodType.PROTEIN,120);
			listOfIngredients.add(toAdd);
			System.out.println("Output:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		}
		catch(Exception ex){
			System.out.println("Test Failed - Exception Unhandled");
			ex.printStackTrace();
		}
	}
	public static void testCase4() {
		try {
			testCaseStart(4,"Ingredient Management","Adding an ingredient with errorneous food type.");
			System.out.println("Input: Name-Beef FoodType-FoodType.PROTEIN CaloriesPer100Grams-120");
			Ingredient toAdd = new Ingredient("Beef", FoodType.ERRORNEOUS,120);
			listOfIngredients.add(toAdd);
			System.out.println("Output:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		}
		catch(Exception ex){
			System.out.println("Test Failed - Exception Unhandled");
			ex.printStackTrace();
		}
	}
	public static void testCase5() {
		try {
			testCaseStart(5,"Ingredient Management","Adding an ingredient with null food type.");
			System.out.println("Input: Name-Beef FoodType-null CaloriesPer100Grams-120");
			Ingredient toAdd = new Ingredient("Beef", null,120);
			listOfIngredients.add(toAdd);
			System.out.println("Output:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		}
		catch(Exception ex){
			System.out.println("Test Failed - Exception Unhandled");
			ex.printStackTrace();
		}
	}
	public static void testCase6() {
		try {
			testCaseStart(6,"Ingredient Management","Adding an ingredient with negative CaloriesPer100Grams.");
			System.out.println("Input: Name-Beef FoodType-FoodType.Protein CaloriesPer100Grams- -1");
			Ingredient toAdd = new Ingredient("Beef", FoodType.PROTEIN,-1);
			listOfIngredients.add(toAdd);
			System.out.println("Output:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		}
		catch(Exception ex){
			System.out.println("Test Failed - Exception Unhandled");
			ex.printStackTrace();
		}
	}
	public static void testCase7() {
		try {
			testCaseStart(7,"Ingredient Management","Adding an ingredient with excessively positive CaloriesPer100Grams.");
			System.out.println("Input: Name-Beef FoodType-FoodType.Protein CaloriesPer100Grams- 999999999");
			Ingredient toAdd = new Ingredient("Beef", FoodType.PROTEIN,999999999);
			listOfIngredients.add(toAdd);
			System.out.println("Output:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		}
		catch(Exception ex){
			System.out.println("Test Failed - Exception Unhandled");
			ex.printStackTrace();
		}
	}
	public static void testCase8() {
		try {
			testCaseStart(8,"Ingredient Management","Adding an ingredient with excessively negative CaloriesPer100Grams.");
			System.out.println("Input: Name-Beef FoodType-FoodType.Protein CaloriesPer100Grams- -999999999");
			Ingredient toAdd = new Ingredient("Beef", FoodType.PROTEIN,-999999999);
			listOfIngredients.add(toAdd);
			System.out.println("Output:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		}
		catch(Exception ex){
			System.out.println("Test Failed - Exception Unhandled");
			ex.printStackTrace();
		}
	}
	public static void testCase9() {
		try {			
			testCaseStart(9,"Ingredient Management","Deleting a premade ingredient.");
			System.out.println("Input: Name-Beef FoodType-FoodType.PROTEIN CaloriesPer100Grams-120");
			Ingredient toAdd = new Ingredient("Beef", FoodType.PROTEIN,120);
			listOfIngredients.add(toAdd);
			System.out.println("Deleting ingredient.");
			deleteObject("Ingredient");
			
			System.out.println("Output:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		}
		catch(Exception ex){
			System.out.println("Test Failed - Exception Unhandled");
			ex.printStackTrace();
		}
	}
	public static void testCase10() {
		try {			
			testCaseStart(10,"Ingredient Management","Deleting a null ingredient.");
			System.out.println("Deleting ingredient.");
			deleteObject("Ingredient");
			
			System.out.println("Output:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		}
		catch(Exception ex){
			System.out.println("Test Failed - Exception Unhandled");
			ex.printStackTrace();
		}
	}
	public static void testCase11() {
		try {			
			testCaseStart(11,"Ingredient Management","Deleting all ingredients with a premade list.");
			System.out.println("Deleting ingredient.");
			listOfIngredients.add(new Ingredient("Beef",FoodType.PROTEIN,100));
			wipeListOfObject("Ingredient");
			
			System.out.println("Output:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		}
		catch(Exception ex){
			System.out.println("Test Failed - Exception Unhandled");
			ex.printStackTrace();
		}
	}
	public static void testCase12() {
		try {			
			testCaseStart(12,"Ingredient Management","Deleting all ingredients in an empty list.");
			System.out.println("Deleting all ingredients.");
			wipeListOfObject("Ingredient");
			
			System.out.println("Output:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		}
		catch(Exception ex){
			System.out.println("Test Failed - Exception Unhandled");
			ex.printStackTrace();
		}
	}
	public static void testCase13() {
		try {			
			testCaseStart(13,"Ingredient Management","Viewing an ingredient in a premade list.");
			System.out.println("Viewing an ingredient.");
			listOfIngredients.add(new Ingredient("Beef",FoodType.PROTEIN,100));
			
			System.out.println("Output:\n");
			viewObject("Ingredient");
			testCaseEnd();
			return;
		}
		catch(Exception ex){
			System.out.println("Test Failed - Exception Unhandled");
			ex.printStackTrace();
		}
	}
	public static void testCase14() {
		try {			
			testCaseStart(14,"Ingredient Management","Viewing an ingredient in an empty list.");
			System.out.println("Viewing an ingredient.");
			
			System.out.println("Output:\n");
			viewObject("Ingredient");
			testCaseEnd();
			return;
		}
		catch(Exception ex){
			System.out.println("Test Failed - Exception Unhandled");
			ex.printStackTrace();
		}
	}
	public static void testCase15() {
		try {			
			testCaseStart(15,"Ingredient Management","Viewing all ingredients in a premade list.");
			System.out.println("Viewing an ingredient.");
			listOfIngredients.add(new Ingredient("Beef",FoodType.PROTEIN,100));
			
			System.out.println("Output:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		}
		catch(Exception ex){
			System.out.println("Test Failed - Exception Unhandled");
			ex.printStackTrace();
		}
	}
	public static void testCase16() {
		try {			
			testCaseStart(16,"Ingredient Management","Viewing all ingredients in an empty list.");
			System.out.println("Viewing an ingredient.");
			
			System.out.println("Output:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		}
		catch(Exception ex){
			System.out.println("Test Failed - Exception Unhandled");
			ex.printStackTrace();
		}
	}
	public static void testCase17() {
		try {			
			testCaseStart(17,"Ingredient Management","Updating an ingredient in a premade list.");
			listOfIngredients.add(new Ingredient("Beef",FoodType.PROTEIN,100));
			System.out.println("Updating an ingredient.");
			updateObject("Ingredient");
			System.out.println("Output:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		}
		catch(Exception ex){
			System.out.println("Test Failed - Exception Unhandled");
			ex.printStackTrace();
		}
	}
	public static void testCase18() {
		try {			
			testCaseStart(17,"Ingredient Management","Updating an ingredient in an empty list.");
			System.out.println("Updating an ingredient.");
			updateObject("Ingredient");
			System.out.println("Output:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		}
		catch(Exception ex){
			System.out.println("Test Failed - Exception Unhandled");
			ex.printStackTrace();
		}
	}
	public static void testCaseR1() {
		try {			
			testCaseStart(11,"Recipe Management","Deleting a premade Recipe.");
			System.out.println("Input: Name-Beef FoodType-FoodType.PROTEIN CaloriesPer100Grams-120");
			Recipe toAdd = new Recipe();
			toAdd = new Recipe("Beef Stew", new Ingredient[] {new Ingredient()}, new String[] {"Beef"}, new String[] {"Cupful"});
			listOfRecipes.add(toAdd);
			System.out.println("Deleting Recipe.");
			deleteObject("Recipe");
			
			System.out.println("Output:\n");
			testCaseEnd();
			return;
		}
		catch(Exception ex){
			System.out.println("Test Failed - Exception Unhandled");
			ex.printStackTrace();
		}
	}
	public static void testCaseR2() {
		try {			
			testCaseStart(12,"Recipe Management","Deleting a null Recipe.");
			System.out.println("Deleting Recipe.");
			deleteObject("Recipe");
			
			System.out.println("Output:\n");
			testCaseEnd();
			return;
		}
		catch(Exception ex){
			System.out.println("Test Failed - Exception Unhandled");
			ex.printStackTrace();
		}
	}
}
