/**
 * @author Daniel Mackle
 * @id 40407187
 * @date 11/11/2023
 */
package part01;

import java.util.ArrayList;

/**
 * @summary holds data of a specific type of ingredient. Only holds data, does
 *          not manipulate data.
 * @type Public Class
 * @dependency Utility
 */
public class Ingredient {
	// Private Instance Variables
	/**
	 * @reference ingredientID
	 * @summary holds the unique ID of the ingredient
	 */
	private int ingredientID;
	/**
	 * @reference ingredientName
	 * @summary holds the name the ingredient
	 */
	private String ingredientName;
	/**
	 * @reference foodType
	 * @summary holds the enum foodtype of the ingredient
	 */
	private FoodType foodType;
	/**
	 * @reference caloriesPer100Grams
	 * @summary holds the floating point value for the caloric energy of the
	 *          ingredient per 100 grams
	 */
	private float caloriesPer100Grams;
	// Private Class Variables
	// holds the number of the ID of the next instance. Is appreciated upon
	// successful instantiation.
	private static int nextIngredientID = 0;

	// Public Constructors
	/**
	 * @summary Empty Constructor
	 */
	public Ingredient() {
	}

	/**
	 * @summary Constructor - Saves full data of Object
	 * @param String   'ingredientName' - name of ingredient
	 * @param FoodType 'foodType' - food type (enumerated)
	 * @param int      'amountHeld' - amount of ingredients per instance of an
	 *                 ingredient type
	 * @param float    'caloriesPer100Grams' - name of ingredient
	 * @throws Exception
	 */
	public Ingredient(String ingredientName, FoodType foodType, float caloriesPer100Grams) throws Exception {
		setIngredientID(getNextIngredientID());
		try {
			setIngredientName(ingredientName);
			setFoodType(foodType);
			setCaloriesPer100Grams(caloriesPer100Grams);
		} catch (Exception exception) {
			throw new Exception();
		}
	}

	// Public Properties
	/**
	 * @reference getIngredientID
	 * @summary accessor
	 * @return integer ingredientID
	 */
	public int getIngredientID() {
		return this.ingredientID;
	}

	/**
	 * @reference getNextIngredientID
	 * @summary accessor - increases this.nextIngredientID after returning
	 * @return static integer nextIngredientID
	 */
	public int getNextIngredientID() {
		return nextIngredientID++;
	}

	/**
	 * @reference getIngredientName
	 * @summary accessor
	 * @return String ingredientName
	 */
	public String getIngredientName() {
		return this.ingredientName;
	}

	/**
	 * @reference getFoodType
	 * @summary accessor
	 * @return integer foodType
	 */
	public FoodType getFoodType() {
		return this.foodType;
	}

	/**
	 * @reference getCaloriesPer100Grams
	 * @summary accessor
	 * @return float caloriesPer100Grams
	 */
	public float getCaloriesPer100Grams() {
		return this.caloriesPer100Grams;
	}

	/**
	 * @reference setIngredientID
	 * @summary mutator - checks validation with Util
	 * @dependency Util
	 * @param ingredientID - new Unique ID of the type of Ingredient
	 * @throws Exception
	 */
	public void setIngredientID(int ingredientID) throws Exception {
		if (!Utility.validatePositiveInt(ingredientID)) {
			throw new Exception();
		}
		this.ingredientID = ingredientID;
	}

	/**
	 * @reference setIngredientName
	 * @summary mutator - checks validation with Util
	 * @dependency Util
	 * @param ingredientName - new name of the type of Ingredient
	 * @throws Exception
	 */
	public void setIngredientName(String ingredientName) throws Exception {
		if (!Utility.validateString(ingredientName)) {
			throw new Exception();
		}
		this.ingredientName = ingredientName;
	}

	/**
	 * @reference setFoodType
	 * @summary mutator - checks validation with Util
	 * @dependency Util
	 * @param foodType - new food type of the ingredient
	 * @throws Exception
	 */
	public void setFoodType(FoodType foodType) throws Exception {
		if (!Utility.validateFOODTYPE(foodType)) {
			throw new Exception();
		}
		this.foodType = foodType;
	}

	/**
	 * @reference caloriesPer100Grams
	 * @summary mutator - checks validation with Util
	 * @dependency Util
	 * @param caloriesPer100Grams - the calories Per 100 Grams of the Ingredient
	 * @throws Exception
	 */
	public void setCaloriesPer100Grams(float caloriesPer100Grams) throws Exception {
		if (!Utility.validatePositiveFloat(caloriesPer100Grams)) {
			throw new Exception();
		}
		this.caloriesPer100Grams = caloriesPer100Grams;
	}

	// Public Methods
	/**
	 * @summary Returns a String representing the state of the instance
	 * @type Public Method
	 * @return String - message tied to enumerated type
	 */
	public String toString() {
		return "Ingredient ID:" + this.getIngredientID() + "\nIngredient Name: " + this.getIngredientName()
				+ "\nFood Type: " + this.getFoodType() + "\nCalories Per 100 Grams: " + this.getCaloriesPer100Grams();
	}

	public static Ingredient getIngredientFromID(int id, ArrayList<Ingredient> listOfIngredients) {
		for (Ingredient ingredient : listOfIngredients) {
			if (ingredient.getIngredientID() == id) {
				return ingredient;
			}
		}
		return null;
	}

	public void toStringShort() {
		System.out.println("ID: "+this.getIngredientID()+" Name: "+this.getIngredientName());
	}
}