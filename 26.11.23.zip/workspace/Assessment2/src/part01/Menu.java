package part01;

public class Menu {
	private String items[];
	private String title;

	public Menu(String title, String data[]) {
		this.title = title;
		this.items = data;
	}

	private void display() {
		System.out.println(title);
		for (int count = 0; count < title.length(); count++) {
			System.out.print("+");
		}
		System.out.println();
		for (int option = 1; option <= items.length; option++) {
			System.out.println(option + ". " + items[option - 1]);
		}
		System.out.println();
	}

	public int getUserChoice() {
		display();
		System.out.print("Enter Selection: ");
		int value = UtilityInput.takeIntFromScanner();
		
		return value;
	}
}
