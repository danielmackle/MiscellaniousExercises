/**
 * @author Daniel Mackle
 * @id 40407187
 * @date 11/11/2023
 */
package part01;

import java.util.ArrayList;

/**
 * Used to perform common misc. manipulations of data to save lines.
 */
public abstract class Utility {
	/**
	 * Takes int ID input and validates whether it is valid or invalid. ID starts at
	 * 0.
	 * 
	 * @param int 'ID' - Identification integer input
	 * @return boolean - True for pass, False for Fail
	 */
	public static boolean validatePositiveInt(int ID) {
		try {
			if (ID < 0 | ID > 2147483647) {
				throw new IllegalArgumentException("Integer outside boundaries.");
			}
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * Takes float input and validates whether it is valid or invalid.
	 * 
	 * @param int 'ID' - Identification integer input
	 * @return boolean - True for pass, False for Fail
	 */
	public static boolean validatePositiveFloat(float ID) {
		try {
			if (ID < 0 | ID > 2147483647) {
				throw new IllegalArgumentException("Float outside boundaries.");
			}
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * Takes FOODTYPE and validates whether it is erroneous.
	 * 
	 * @param enum FOODTYPE 'foodtype'
	 * @return boolean - True for pass, False for Fail
	 */
	public static boolean validateFOODTYPE(FoodType foodType) {
		try {
			if (foodType == FoodType.ERRORNEOUS) {
				throw new IllegalArgumentException(foodType.toString());
			}
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * Takes String input and validates whether it is erroneous.
	 * 
	 * @param String 'string'
	 * @return boolean - True for pass, False for Fail
	 */
	public static boolean validateString(String stringToValidate) {
		try {
			if (stringToValidate == "") {
				throw new IllegalArgumentException("String is Null");
			}
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * Takes String Array and outputs as a single String.
	 * 
	 * @param String[] 'stringArray'
	 * @return String - String output representing all Strings in the Array
	 */
	public static String stringArrayToString(String[] stringArray) {
		String response = "";
		for (String string : stringArray) {
			response += string;
		}
		return response;
	}

	/**
	 * Takes Object Array input and and outputs as a single String representation.
	 * 
	 * @param Ingredient[] 'ingredientArray'
	 * @return boolean - False for pass, True for Fail
	 */
	public static String objectArrayToString(Object[] objectArray) {
		String response = "";
		for (Object object : objectArray) {
			response += object.toString();
		}
		return response;
	}

	/**
	 * Takes 2DArray input and and outputs as a single String representation.
	 * 
	 * @param Ingredient[] 'ingredientArray'
	 * @return boolean - False for pass, True for Fail
	 */
	public static String recipe2DArrayToString(Recipe[][] recipe2DArray) {
		String response = "";
		for (Recipe[] recipe1DArray : recipe2DArray) {
			for (Recipe recipe : recipe1DArray) {
				response += recipe.toString();
			}
		}
		return response;
	}

	/**
	 * Exits program normally, with valid exit flag.
	 */
	public static void Exit() {
		System.out.println("\n");
		System.out.println("Happy to help! Closing now.");
		System.exit(0);
	}
	public static void collectionsSwapRipoff(ArrayList<Ingredient> list, int i, int j) {
		//let me use util.collections.swap pleeeeeaseeeee i beg
	    Ingredient ing = list.get(i);
	    list.set(i, list.get(j));
	    list.set(j, ing);
	}
	@SuppressWarnings("unused")
	public static void sortIngredientList(ArrayList<Ingredient> listOfIngredients, boolean ascending, String type) throws Exception {
		switch (type) {
		case "ID":
			for (int i = 0; i < listOfIngredients.size() - 1; i++) {
				for (int j = 0; j < listOfIngredients.size() - i - 1; j++) {
					int id= listOfIngredients.get(j).getIngredientID();
					int id2= listOfIngredients.get(j + 1).getIngredientID();
					if ((listOfIngredients.get(j).getIngredientID() > listOfIngredients.get(j + 1).getIngredientID() && ascending )||(listOfIngredients.get(j).getIngredientID() < listOfIngredients.get(j + 1).getIngredientID() && !ascending)) {
						collectionsSwapRipoff(listOfIngredients, i, i + 1);
					}
				}
			}
			return;
		case "Name":
			for (int i = 0; i < listOfIngredients.size() - 1; i++) {
				for (int j = 0; j < listOfIngredients.size() - i - 1; j++) {
					if (listOfIngredients.get(j).getIngredientName().compareTo(listOfIngredients.get(j + 1).getIngredientName()) == 1 && ascending ||listOfIngredients.get(j).getIngredientName().compareTo(listOfIngredients.get(j + 1).getIngredientName()) == -1 && !ascending) {
						String name= listOfIngredients.get(j).getIngredientName();
						String name2= listOfIngredients.get(j + 1).getIngredientName();
						collectionsSwapRipoff(listOfIngredients, i, i + 1);
					}
				}
			}
			return;
		case "FoodType":
			for (int i = 0; i < listOfIngredients.size() - 1; i++) {
				for (int j = 0; j < listOfIngredients.size() - i - 1; j++) {
					if (listOfIngredients.get(j).getFoodType().ordinal() > listOfIngredients.get(j + 1).getFoodType().ordinal() && ascending ||listOfIngredients.get(j).getFoodType().ordinal() < listOfIngredients.get(j + 1).getFoodType().ordinal() && !ascending) {
						collectionsSwapRipoff(listOfIngredients, i, i + 1);
					}
				}
			}
			return;
		case "CaloriesPer100Grams":
			for (int i = 0; i < listOfIngredients.size() - 1; i++) {
				for (int j = 0; j < listOfIngredients.size() - i - 1; j++) {
					if (listOfIngredients.get(j).getCaloriesPer100Grams() > listOfIngredients.get(j + 1).getCaloriesPer100Grams() && ascending ||listOfIngredients.get(j).getCaloriesPer100Grams() < listOfIngredients.get(j + 1).getCaloriesPer100Grams() && !ascending) {
						collectionsSwapRipoff(listOfIngredients, i, i + 1);
					}
				}
			}
			return;
		}
		return;
	}

	public static void ListArrayToStringShort(ArrayList<Ingredient> list) {
		for(Ingredient i : list) {
			i.toStringShort();
		}
	}
}