package messing;
import java.util.Scanner;
import java.util.ArrayList;
/**
 * Creates and displays a menu text based ui. 
 * Takes +ve int input selection and passes to AnimalMenu.java
 * Returns -1 if the selection corresponds to MENUOPTION.EXIT
 * Catches invalid user input for option selection.
 * @author HyenaGaming
 * @version 1
 * @date 22.10.2023
 */
public class Menu {
	private static Scanner input = new Scanner(System.in);
	//Private Methods
	public static void displayMenuOptions(String title,ArrayList<String>optionsTitle) {
		System.out.print("\n"+title+":\n");
		for(int i=0; i<(title.length()+1);i++) {
			System.out.print("*");
		}
		for(int i=0;i<(optionsTitle.size()-1);i++) {
			System.out.print("\n"+i+": "+optionsTitle.get(i));
		}
	}
	/**
	 * Takes integer input from the user. Returns -1 if system is exited.
	 * Will loop until valid int is inputed.
	 * @param options - array list of MENUOPTON classes to check if = MENUOTION.EXIT
	 * @return -1 if exit, +ve natural number if not exit
	 */
	public static int takeInput(ArrayList<MENUOPTION> options) {
		while(true) {
			System.out.println("\nPlease enter a choice: ");
			try {
				System.out.println();
				String s = input.nextLine();
				int output = Integer.parseInt(s);
				System.out.println();
				if(options.get(output)==MENUOPTION.EXIT) {
					return -1;
				}
				return output;
			}
			catch(Exception ex) {
				System.out.println("Sorry! Input was invalid. Please try again!");
			}
		}
	}
}