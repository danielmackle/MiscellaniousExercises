package studentManagement;

public enum SUBJECT {
	ENGLISH_LANGUAGE("English"),
	MATHEMATICS("Mathematics"),
	FURTHER_MATHEMATICS("Further Mathematics"),
	PHYSICS("Physics"),
	BIOLOGY("Biology"),
	CHEMISTRY("Chemistry"),
	ENGLISH_LITERATURE("English Literature");
	private String input;
	SUBJECT(String input){
		this.input = input;
	}
	public String toString() {
		return input;
	}
}
