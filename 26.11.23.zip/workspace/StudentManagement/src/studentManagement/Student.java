/**
 * @author 40407187
 * @version 1.0
 */
package studentManagement;

/**
 * Manages data for one Student instance in the database
 */
public class Student {
	/**
	 * Private Instance Variables
	 */
	private int ID;
	private static int nextID;
	private String name;
	private GENDER gender;
	private char formClass;
	private int year;
	private SUBJECT[] subjectsALevel = new SUBJECT[3];
	private GRADE[] gradesALevel = new GRADE[3];
	/**
	 * Public Instance Properties
	 * For getters: @return value
	 */
	public int getID() {
		return this.ID;
	}
	public void setID(int ID) {
		this.ID = ID;
	}
	public int getNextID() {
		return this.nextID;
	}
	public void setNextID(int nextID) {
		this.nextID = nextID;
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public GENDER getGender() {
		return this.gender;
	}
	public void setGender(GENDER gender) {
		this.gender = gender;
	}
	public char getFormClass() {
		return this.formClass;
	}
	public void setFormClass(char formClass) {
		this.formClass = formClass;
	}
	public int getYear() {
		return this.year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public SUBJECT[] getSubjectsALevel() {
		return this.subjectsALevel;
	}
	public void setSubjectsALevel(SUBJECT[] subjectsALevel) {
		this.subjectsALevel = subjectsALevel;
	}
	public GRADE[] getGradesALevel() {
		return this.gradesALevel;
	}
	public void setGradesALevel(GRADE[] gradesALevel) {
		this.gradesALevel = gradesALevel;
	}
	/**
	 * Public Constructors
	 */
	public Student() {
		ID = -1;
	}
}
