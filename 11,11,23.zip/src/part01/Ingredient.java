/**
 * @author Daniel Mackle
 * @id 40407187
 * @date 11/11/2023
 */
package part01;

import part01.Util.Utility;

/**
 * @summary holds data of a specific type of ingredient. Only holds data, does not manipulate data.
 * @type Public Class
 * @dependency part01.Utility
 * @version 0.1
 * todo: implement interface
 */
public class Ingredient {
	//Private Instance Variables
	private int ingredientID;
	private FOODTYPE foodType;
	private int amountHeld;
	private float caloriesPer100Grams;
	//Private Class Variables
	//holds the number of the ID of the next instance. Is appreciated upon successful instantiation.
	private static int nextID=0;
	public int getIngredientID() {
		return this.ingredientID;
	}
	public FOODTYPE getFoodType() {
		return this.foodType;
	}
	public int getAmountHeld(){
		return this.amountHeld;
	}
	public float getCaloriesPer100Grams(){
		return this.caloriesPer100Grams;
	}
	public void setIngredientID(int ingredientID) {
		if(Utility.validateID(ingredientID)) {
			return;
		}
		this.ingredientID = ingredientID;
	}
	public void setFoodType(FOODTYPE foodType) {
		if(Utility.validateFOODTYPE(ingredientID)) {
			return;
		}
		this.ingredientID = ingredientID;
	}
	public void setAmountHeld(int amountHeld){
		
	}
	public void setCaloriesPer100Grams(double caloriesPer100Grams){
		
	}
}
