/**
 * @author Daniel Mackle
 * @id 40407187
 * @date 11/11/2023
 */
package part01;

/**
 * 
 */
public class InvalidIDException extends Exception {
	/**
	 * SerialisableUniqueID - used to recognise the specific instance
	 * @extends Exception
	 */
	private static final long serialVersionUID = -8538693780270649405L;
	public InvalidIDException() {
		super();
	}
	public InvalidIDException(String message) {
		super(message);
	}
	public InvalidIDException(String message, Throwable cause) {
		super(message, cause);
	}
	public InvalidIDException(Throwable cause) {
		super(cause);
	}
	@Override public String getMessage() {
		return ("Invalid ID.\nDetails: " +super.getMessage());
	}
}
