package part01;

public enum FOODTYPE {
	ERRORNEOUS("Errorneous Food Type");
	private String message;
	private FOODTYPE(String message) {
		this.message = message;
	}
	public String toString() {
		return message;
	}
}
