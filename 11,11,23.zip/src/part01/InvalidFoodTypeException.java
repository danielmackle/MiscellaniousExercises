/**
 * @author Daniel Mackle
 * @id 40407187
 * @date 11/11/2023
 */
package part01;
public class InvalidFoodTypeException extends Exception{
	/**
	 * SerialisableUniqueID - used to recognise the specific instance
	 * @extends Exception
	 */
	private static final long serialVersionUID = -631185814669725926L;
	public InvalidFoodTypeException() {
		super();
	}
	public InvalidFoodTypeException(String message) {
		super(message);
	}
	public InvalidFoodTypeException(String message, Throwable cause) {
		super(message, cause);
	}
	public InvalidFoodTypeException(Throwable cause) {
		super(cause);
	}
	@Override public String getMessage() {
		return ("Invalid ID.\nDetails: " +super.getMessage());
	}
}
