/**
 * @author Daniel Mackle
 * @id 40407187
 * @date 11/11/2023
 */
package part01.Util;

import part01.FOODTYPE;
import part01.InvalidFoodTypeException;
import part01.InvalidIDException;

/**
 * @summary used to perform common misc. manipulations of data to save lines.
 * @type Abstract Class
 * @dependency none
 * @version 0.1
 */
abstract class Utility {
	/**
	 * @summary Takes input of an object and validates whether it is valid or invalid. ID starts at 0.
	 * @param int 'ID' - Identification integer input
	 * @type Public Static Class
	 * @implements none
	 * @return boolean - False for pass, True for Fail
	 */
	protected static boolean validateID(int ID){
		try 
		{
			if(ID <= 0) {
				throw new InvalidIDException("ID less than 0.");
			}
			if(ID > 2147483647) {
				throw new InvalidIDException("ID too large.");
			}
		}
		catch(InvalidIDException invalidIDException)
		{
			System.out.println(invalidIDException.getMessage());
			return false;
		}
		return true;
	}
	protected static boolean validateFOODTYPE(FOODTYPE foodType) {
		try 
		{
			if(foodType == FOODTYPE.ERRORNEOUS) {
				Utility.throwInvalidFoodTypeException(foodType.toString());
			}
		}
		catch(InvalidFoodTypeException invalidFoodTypeException)
		{
			System.out.println(invalidFoodTypeException.getMessage());
			return false;
		}
		return true;
	}
	/**
	 * @desc Creates and throws an InvalidIDException with the custom message inputed.
	 * @param String 'message' - Custom String to be held in the exception instance
	 * @type Public Static Class
	 * @implements Throwable
	 * @return none
	 */
	public static void throwInvalidIDException(String message) throws InvalidIDException {
		InvalidIDException invalidIDException = new InvalidIDException(message);
		throw invalidIDException;
	}
	/**
	 * @desc Creates and throws an InvalidIDException with the custom message inputed.
	 * @param String 'message' - Custom String to be held in the exception instance
	 * @type Public Static Class
	 * @implements Throwable
	 * @return none
	 */
	public static void throwInvalidFoodTypeException(String message) throws InvalidFoodTypeException {
		part01.InvalidFoodTypeException invalidFoodTypeException = new part01.InvalidFoodTypeException(message);
		throw invalidFoodTypeException;
	}
}
