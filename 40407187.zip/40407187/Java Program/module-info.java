module DM40407187 {
	requires java.sql;
}