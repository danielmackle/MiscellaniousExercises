Daniel Mackle 40407187

ChatGPT or any other AI model was not used at all in the making of the work for this Assessment.

-------------PART01-------------
Part01 (folder) - holds the .java files containing the code for part01.

UML.png - Holds my UML diagram for all data-transporting classes. Application classes not included.

-------------PART02-------------
Part02 (folder) - holds the .java files containing the code for part02.
Test Case Evidence - Holds screenshots of the output of every test case. 
Testting Template - Holds the speification and details of every test case. 


-------------PART03-------------
Part03 (folder) - holds the .java files containing the code for part03.