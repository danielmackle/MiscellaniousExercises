/**
 * @author Daniel Mackle
 * @id 40407187
 * @date 12/11/2023
 */
package part03;

import java.util.ArrayList;

/**
 * Holds data of a specific recipe. Only holds data, does not manipulate data.
 */
public class Recipe {
	// Private Instance Variables
	/**
	 * Holds the unique ID of the recipe
	 */
	private int recipeID;
	/**
	 * Holds the name of the recipe
	 */
	private String recipeName;
	/**
	 * Holds an array of each ingredient instance representing a type of ingredient
	 * in the recipe
	 */
	private Ingredient[] ingredients;
	/**
	 * Holds an array of Strings
	 */
	private String[] ingredientsGuidance;
	/**
	 * Holds the unique ID of the ingredient
	 */
	private String[] methodInstructions;
	/**
	 * Holds the unique ID of the ingredient
	 */
	private static int nextRecipeID = 0;

	// Public Constructors
	/**
	 * Empty Constructor
	 */
	public Recipe() {
	}

	/**
	 * Constructor - Saves full data of Object
	 * 
	 * @param int 'message' - Message correlating to the enumerated type
	 * @throws Exception
	 */
	public Recipe(String recipeName, Ingredient[] ingredients, String[] ingredientsGuidance,
			String[] methodInstructions) throws Exception {
		setRecipeID(getNextRecipeID());
		try {
			setRecipeName(recipeName);
			setIngredients(ingredients);
			setIngredientsGuidance(ingredientsGuidance);
			setMethodInstructions(methodInstructions);
		} catch (Exception ex) {
			throw new Exception();
		}
	}

	// Public Properties
	/**
	 * Accessor
	 * 
	 * @return integer recipeID - Data to be accessed
	 */
	public int getRecipeID() {
		return this.recipeID;
	}

	/**
	 * Accessor - increases this.nextRecipeID after returning
	 * 
	 * @return integer nextRecipeID - Data to be accessed
	 */
	public int getNextRecipeID() {
		return nextRecipeID++;
	}

	/**
	 * Accessor
	 * 
	 * @return String recipeName - Data to be accessed
	 */
	public String getRecipeName() {
		return this.recipeName;
	}

	/**
	 * Accessor
	 * 
	 * @return Ingredient[] ingredients - Data to be accessed
	 */
	public Ingredient[] getIngredients() {
		return this.ingredients;
	}

	/**
	 * Accessor
	 * 
	 * @return String[] ingredientsGuidance - Data to be accessed
	 */
	public String[] getIngredientsGuidance() {
		return this.ingredientsGuidance;
	}

	/**
	 * Accessor
	 * 
	 * @return String[] methodInstructions - Data to be accessed
	 */
	public String[] getMethodInstructions() {
		return this.methodInstructions;
	}

	/**
	 * Mutator - checks validation with Util
	 * 
	 * @param int recipeID - new unique id of the recipe
	 * @throws Exception
	 */
	public void setRecipeID(int recipeID) throws Exception {
		if (!Utility.validatePositiveInt(recipeID)) {
			throw new Exception();
		}
		this.recipeID = recipeID;
	}

	/**
	 * Mutator - checks validation with Util
	 * 
	 * @param String recipeName - new name of recipe
	 * @throws Exception
	 */
	public void setRecipeName(String recipeName) throws Exception {
		if (!Utility.validateString(recipeName)|| recipeName.length()>25) {
			throw new Exception();
		}
		this.recipeName = recipeName;
	}

	/**
	 * Mutator - checks validation with Util
	 * 
	 * @param Ingredients[] ingredients - array of all ingredient types in the
	 *                      recipe
	 * @throws Exception
	 */
	public void setIngredients(Ingredient[] ingredients) throws Exception {
		for (Ingredient ingredient : ingredients) {
			{
				if (!Utility.validatePositiveInt(ingredient.getIngredientID())) {
					throw new Exception();
				}
			}
		}
		this.ingredients = ingredients;
	}

	/**
	 * Mutator - checks validation with Util
	 * 
	 * @param String[] ingredientsGuidance - String array containing additional
	 *                 instructions for each type of ingredient
	 * @throws Exception
	 */
	public void setIngredientsGuidance(String[] IngredientsGuidance) throws Exception {
		for (String ingredientsGuidance : IngredientsGuidance) {
			if (!Utility.validateString(ingredientsGuidance)) {
				throw new Exception();
			}
		}
		this.ingredientsGuidance = IngredientsGuidance;
	}

	/**
	 * Mutator - checks validation with Util
	 * 
	 * @param String[] methodInstructions - string array of steps of the method
	 * @throws Exception
	 */
	public void setMethodInstructions(String[] MethodInstructions) throws Exception {
		for (String methodInstructions : MethodInstructions) {
			if (!Utility.validateString(methodInstructions)) {
				throw new Exception();
			}
		}
		this.methodInstructions = MethodInstructions;
	}

	// Public Methods
	/**
	 * Returns a String representing the state of the instance
	 * 
	 * @return String - message tied to enumerated type
	 */
	public String toString() {
		return "Recipe ID: " + this.getRecipeID() + "\nRecipe Name: " + this.getRecipeName() + "\n\nIngredients: \n"
				+ Utility.objectArrayToString(this.getIngredients()) + "\n\nGuidance for Ingredients: "
				+ Utility.stringArrayToString(this.getIngredientsGuidance()) + "\nMethod: "
				+ Utility.stringArrayToString(this.getMethodInstructions()) + "\n";
	}

	public static Recipe getRecipeFromID(int ID, ArrayList<Recipe> listOfRecipes) {
		for (Recipe recipe : listOfRecipes) {
			if (recipe.getRecipeID() == ID) {
				return recipe;
			}
		}
		return null;
	}

	public String toStringShort() {
		return "ID: " + this.getRecipeID() + " Name: " + this.getRecipeName()+"\n";
	}
}
