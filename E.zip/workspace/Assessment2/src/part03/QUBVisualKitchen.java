package part03;

import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.ImageIcon;

import console.Console;

public class QUBVisualKitchen {
	/**
	 * Holds the created Ingredients across the entire program
	 */
	protected static ArrayList<Ingredient> listOfIngredients = new ArrayList<Ingredient>();
	/**
	 * Holds the created Recipes across the entire program
	 */
	protected static ArrayList<Recipe> listOfRecipes = new ArrayList<Recipe>();
	/**
	 * Holds the current Weekly Menu to be manipulated
	 */
	protected static Recipe[][] weeklyMenu = new Recipe[3][3];

	
	
	public static Console con = new Console(true);

	/**
	 * Entry point of the program - makes preset values and runs the main menu
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// Set the width and height for the console
		con.setSize(600, 200);

		// Set the title of the console popup
		con.setTitle("QUB Visual Kitchen");

		// Make sure the console is visible to the user
		con.setVisible(true);

		con.setBgColour(Color.black);

		con.setBounds(0, 0, 1000, 800);

		// You can modify the Font and Colour of text
		con.setFont(new Font("Courier", Font.BOLD, 30));
		con.setColour(Color.white);

		con.print("Would you like to generate premade values for quick testing?:");
		boolean valid = false;
		boolean generate = false;
		while (!valid) {
			try {
				generate = UtilityInput.takeBooleanFromConsole();
				valid = true;
			} catch (Exception ex) {
				con.println("Sorry! That input was not vaalid. Please try again.");
			}
		}
		if (generate) {
			try {
				setPresetValues();
				con.println("Premade values loaded.");
			} catch (Exception ex) {
				con.println("Error creating premade values.");
			}
		}
		mainMenu();
	}

	/**
	 * Sets preset values for easy testing. Wipes all previous data.
	 * @throws Exception (but will never be thrown)
	 */
	public static void setPresetValues() throws Exception {
		listOfIngredients.clear();
		listOfRecipes.clear();
		weeklyMenu = new Recipe[3][3];
		listOfIngredients.add(new Ingredient("Beef", FOODTYPE.PROTEIN, 100));
		listOfIngredients.add(new Ingredient("Pork", FOODTYPE.PROTEIN, 300));
		listOfIngredients.add(new Ingredient("Potato", FOODTYPE.PROTEIN, 300));
		listOfRecipes.add(new Recipe("Beef Stew",
				new Ingredient[] { listOfIngredients.get(0), listOfIngredients.get(2) },
				new String[] { "Seperated", "Mashed" },
				new String[] { "1. Mash Potatoes", "2. Fry Beef in pan", "3. Use beef stock cubes", "4. Assemble" }));
		listOfRecipes.add(new Recipe("Pork Stew",
				new Ingredient[] { listOfIngredients.get(2), listOfIngredients.get(2) },
				new String[] { "Cut into chunks", "Mashed" },
				new String[] { "1. Mash Potatoes", "2. Fry Pork in pan", "3. Use pork stock cubes", "4. Assemble" }));
		weeklyMenu[0][0] = listOfRecipes.get(0);
		weeklyMenu[1][0] = listOfRecipes.get(1);
	}
	
	/**
	 * Displays the main menu which navigates the user to the more specified menuss
	 */
	protected static void mainMenu() {
		while (true) {
			try {
				UtilityInput.printImage("\\qubCrest.png");
				Menu mainMenu = new Menu("Queen's University Belfast Kitchen",
						new String[] { "Manage Ingredients", "Manage Recipes", "Manage the Weekly Menu", "Exit" });
				switch (mainMenu.getUserChoice()) {
				case (1):
					// Manage Ingredients
					con.clear();
					manageIngredientsMenu();
					break;
				case (2):
					// Manage Recipes
					con.clear();
					manageRecipesMenu();
					break;
				case (3):
					// Manage the Weekly Menu
					con.clear();
					manageWeeklyMenu();
					break;
				case (4):
					// Exit
					con.println("Happy to help! Closing now.");
					System.exit(0);
					break;
				default:
					throw new Exception();
				}
			} catch (Exception ex) {
				con.setColour(Color.red);
				con.println("\nSorry! That Selection was invalid. Please try again!\n");
				con.setColour(Color.white);
			}
		}
	}

	/**
	 * Displays the menu which navigates the user to the functions involving
	 * ingredients
	 */
	private static void manageIngredientsMenu() {
		boolean valid = false;
		while (!valid) {
			try {
				UtilityInput.printImage("\\ingredient.png");
				Menu ingredientMenu = new Menu("Manage Ingredients",
						new String[] { "Add an Ingredient Type", "Delete an Ingredient Type",
								"Delete all Ingredient Types", "View an Ingredient Type", "View all Ingredient Types",
								"Update an Ingredient Type", "Back" });
				switch (ingredientMenu.getUserChoice()) {
				case (1):
					// Add an Ingredient Type
					addObject("Ingredient");
					break;
				case (2):
					// Delete an Ingredient Type
					deleteObject("Ingredient");
					break;
				case (3):
					// Delete all Ingredient Types
					deleteAllObject("Ingredient");
					break;
				case (4):
					// View an Ingredient Type
					viewObject("Ingredient");
					break;
				case (5):
					// View all Ingredient Types
					viewAllObject("Ingredient");
					break;
				case (6):
					// Update an Ingredient Type
					updateObject("Ingredient");
					break;
				case (7):
					valid = true;
					break;
				default:
					throw new Exception();
				}
			} catch (Exception ex) {
				con.setColour(Color.red);
				con.println("\nSorry! That Selection was invalid. Please try again!\n");
				con.setColour(Color.white);
			}
		}
	}

	/**
	 * Displays the menu which navigates the user to the functions involving recipes
	 */
	private static void manageRecipesMenu() {
		boolean valid = false;
		while (!valid) {
			try {
				UtilityInput.printImage("\\recipe.png");
				Menu recipeMenu = new Menu("Manage Recipes", new String[] { "Add a Recipe", "Delete a Recipe",
						"Delete all Recipes", "View a Recipe", "View all Recipes", "Update a Recipe", "Back" });
				switch (recipeMenu.getUserChoice()) {
				case (1):
					// Add a Recipe
					addObject("Recipe");
					break;
				case (2):
					// Delete a Recipe
					deleteObject("Recipe");
					break;
				case (3):
					// Delete all Recipes
					deleteAllObject("Recipe");
					break;
				case (4):
					// View a Recipe
					viewObject("Recipe");
					break;
				case (5):
					// View all Recipes
					viewAllObject("Recipe");
					break;
				case (6):
					// Update a Recipe
					updateObject("Recipe");
					break;
				case (7):
					valid = true;
					break;
				default:
					throw new Exception();
				}
			} catch (Exception ex) {
				con.setColour(Color.red);
				con.println("\nSorry! That Selection was invalid. Please try again!\n");
				con.setColour(Color.white);
			}
		}
	}

	/**
	 * Displays the menu which navigates the user to the functions involving the
	 * weekly menu
	 */
	private static void manageWeeklyMenu() {
		boolean valid = false;
		while (!valid) {
			try {
				UtilityInput.printImage("\\weeklyMenu.png");
				Menu recipeMenu = new Menu("Manage the Weekly Menu",
						new String[] { "Set all Meals", "Update the Meals of a Day", "Update one Meal",
								"View Weekly Menu", "Clear Weekly Menu", "Back" });
				switch (recipeMenu.getUserChoice()) {
				case (1):
					// Fill Weekly Menu
					setAllWeeklyList();
					break;
				case (2):
					// Update a Day in the Weekly Menu
					updateAllMeals();
					break;
				case (3):
					// Update a Meal in the Weekly Menu
					updateOneMeal();
					break;
				case (4):
					// View Weekly Menu
					viewObject("WeeklyMenu");
					break;
				case (5):
					// Wipe the Weekly Menu
					deleteAllObject("WeeklyMenu");
					break;
				case (6):
					valid = true;
					break;
				default:
					throw new Exception();
				}
			} catch (Exception ex) {
				con.setColour(Color.red);
				con.println("\nSorry! That Selection was invalid. Please try again!\n");
				con.setColour(Color.white);
			}
		}
	}

	/**
	 * Takes the needed inputs and constructs either an ingredient or a recipe
	 * instance
	 * 
	 * @param type
	 */
	protected static void addObject(String type) {
		Ingredient toAddI;
		Recipe toAddR;
		try {
			con.clear();
			switch (type) {
			case "Ingredient":
				con.println("Adding an Ingredient Type:");
				toAddI = new Ingredient(UtilityInput.takeName(), UtilityInput.takeFoodType(),
						UtilityInput.takeCaloriesPer100Grams());
				listOfIngredients.add(toAddI);
				con.println(toAddI.toString());
				break;
			case "Recipe":
				if (listOfIngredients.isEmpty()) {
					throw new ArithmeticException();
				}
				con.println("Adding a Recipe Type:");
				String name = UtilityInput.takeName();
				Ingredient[] ingredients = UtilityInput.takeIngredients(listOfIngredients);
				String[] ingredientsGuidance = UtilityInput.takeStringArray("IngredientsGuidance", ingredients.length);
				String[] methodInstructions = UtilityInput.takeStringArray("MethodInstructions", ingredients.length);
				toAddR = new Recipe(name, ingredients, ingredientsGuidance, methodInstructions);
				listOfRecipes.add(toAddR);
				con.println(toAddR.toString());
				break;
			}
		} catch (ArithmeticException imex) {
			con.setColour(Color.red);
			con.println("\nSorry, there are no Ingredients saved to make a Recipe with.");
			con.setColour(Color.white);

		} catch (Exception e) {
			con.setColour(Color.red);
			con.println("\nSorry, an error has occurred in construction. Please try again.");
			con.setColour(Color.white);
		}
		con.println("\n");
	}

	/*
	 * Deletes a user-selected ingredient or recipe. Removes from
	 * listOfIngredients/listOfRecipes
	 */
	protected static void deleteObject(String type) {
		try {
			con.clear();
			con.println("Deleting " + type + ":");
			switch (type) {
			case "Ingredient":
				Ingredient i = UtilityInput.takeIngredient(listOfIngredients);
				Ingredient.deleteIngredient(i, listOfIngredients);
				con.setColour(Color.green);
				con.println("\nThe Ingredient has been deleted.");
				con.setColour(Color.white);
				break;
			case "Recipe":
				Recipe r = UtilityInput.takeRecipe(listOfRecipes);
				if (r != null) {
					listOfRecipes.remove(r);
					con.setColour(Color.green);
					con.println("\nThe Recipe has been deleted.");
					con.setColour(Color.white);
				}
				break;
			}
		} catch (ArithmeticException iex) {
			con.setColour(Color.red);
			con.println("\nSorry! There are no " + type + "s saved to be deleted.");
			con.setColour(Color.white);
		} catch (Exception ex) {
		}
	}

	/*
	 * Deletes all ingredients or recipes. Wipes listOfIngredients/listOfRecipes
	 */
	protected static void deleteAllObject(String type) {
		con.clear();
		try {
			switch (type) {
			case ("Ingredient"):
				if (listOfIngredients.isEmpty()) {
					throw new Exception();
				}
				listOfIngredients.clear();
				break;
			case ("Recipe"):
				if (listOfRecipes.isEmpty()) {
					throw new Exception();
				}
				listOfRecipes.clear();
				break;
			case ("WeeklyMenu"):
				weeklyMenu = new Recipe[3][3];
				break;
			}
			con.setColour(Color.green);
			con.println("All " + type + "s have been deleted.");
			con.setColour(Color.white);
		} catch (Exception ex) {
			con.setColour(Color.red);
			con.println("\nSorry! There are no " + type + "s to be deleted.");
			con.setColour(Color.white);
		}
	}

	/*
	 * Views a user-selected ingredient or recipe. Runs toString for the fetched
	 * object.
	 */
	protected static void viewObject(String type) {
		con.clear();
		try {
			con.println("Viewing " + type + ":");
			switch (type) {
			case "Ingredient":
				if (listOfIngredients.isEmpty()) {
					throw new ArithmeticException();
				}
				con.println("\nSelected Ingredient:\n" + UtilityInput.takeIngredient(listOfIngredients).toString());
				break;
			case "Recipe":
				if (listOfRecipes.isEmpty()) {
					throw new ArithmeticException();
				}
				con.println("\nSelected Recipe:\n" + UtilityInput.takeRecipe(listOfRecipes).toString());
				break;
			case "WeeklyMenu":
				for (int i = 0; i < 4; i++) {
					for (int q = 0; q < 4; q++) {
						con.println("Day: " + i + " Meal:" + q);
						try {
							con.println(weeklyMenu[i][q].toStringShort());
						}
						catch(Exception ex) {
							con.println("Sorry! This menu item is not yet confirmed\n");
						}
						
					}
				}
				break;
			}
		} catch (ArithmeticException ex) {
			con.setColour(Color.red);
			con.println("\nSorry, there are no " + type + "s saved to view.");
			con.setColour(Color.white);
		} catch (Exception ex) {
		}
	}

	/*
	 * Views all user-selected ingredient or recipe. Runs toString for all fetched
	 * objects.
	 */
	protected static void viewAllObject(String type) {
		con.clear();
		// todo display all sorted recipes short
		con.println("Viewing all " + type + "s:");
		switch (type) {
		case ("Recipe"): {
			if (!listOfRecipes.isEmpty()) {
				int count = 0;
				for (Recipe r : listOfRecipes) {
					con.print("Recipe " + ++count + ":\n" + r.toString());
				}
			} else {
				con.setColour(Color.red);
				con.println("\nSorry, there are no " + type + "s saved to view.");
				con.setColour(Color.white);
			}
			break;
		}
		case ("Ingredient"): {
			if (!listOfIngredients.isEmpty()) {
				int count = 0;
				for (Ingredient i : listOfIngredients) {
					con.println("Ingredient " + ++count + ":\n" + i.toString() + "\n");
				}
			} else {
				con.setColour(Color.red);
				con.println("\nSorry, there are no " + type + "s saved to view.");
				con.setColour(Color.white);
			}
			break;
		}
		case ("WeeklyMenu"): {
			int day = 0;
			int meal = 0;
			for (Recipe[] rArray : WeeklyMenu.getRecipesForEachDay()) {
				++day;
				for (Recipe r : rArray) {
					++meal;
					if (r.getRecipeName() != null) {
						con.println("Day: " + day + " Meal: " + meal + "\n" + r.toString());
					} else {
						con.println("Day: " + day + " Meal: " + meal + "\nTo Be Confirmed.");
					}
				}
				meal = 0;
			}
			break;
		}
		}
	}

	/*
	 * Updates a user-selected ingredient or recipe. Runs toString for all fetched
	 * objects.
	 */
	protected static void updateObject(String type) {
		con.clear();
		try {
			switch (type) {
			case "Ingredient":
				if (listOfIngredients.isEmpty()) {
					throw new Exception();
				}
				Ingredient toUpdateI = UtilityInput.takeIngredient(listOfIngredients);
				con.print("Updating Ingredient:\n" + toUpdateI.toString()
						+ "\n1: Name\n2: Food Type\n3: Calories Per 100 Grams\n\nSelect field to Update:");
				switch (UtilityInput.takeIntFromConsole()) {
				case 1:
					toUpdateI.setIngredientName(UtilityInput.takeName());
					con.setColour(Color.green);
					con.println("Name has been updated.");
					con.setColour(Color.white);
					break;
				case 2:
					toUpdateI.setFoodType(UtilityInput.takeFoodType());
					con.setColour(Color.green);
					con.println("Food Type has been updated.");
					con.setColour(Color.white);
					break;
				case 3:
					toUpdateI.setCaloriesPer100Grams(UtilityInput.takeCaloriesPer100Grams());
					con.setColour(Color.green);
					con.println("Calories per 100 Grams has been updated.");
					con.setColour(Color.white);
					break;
				default:
					throw new Exception("Invalid Input.");
				}
				break;
			case "Recipe":
				if (listOfRecipes.isEmpty()) {
					throw new Exception();
				}
				Recipe toUpdateR = UtilityInput.takeRecipe(listOfRecipes);
				con.print("Updating Recipe:\n" + toUpdateR.toString()
						+ "\n 1: Name\n2: Ingredients\n3: Ingredients Guidance\n4: Method Instructions\n\nSelect field to Update:");
				switch (UtilityInput.takeIntFromConsole()) {
				case 1:
					UtilityInput.takeName();
					con.setColour(Color.green);
					con.println("Name has been updated.");
					con.setColour(Color.white);
					break;
				case 2:
					UtilityInput.takeIngredients(listOfIngredients);
					con.setColour(Color.green);
					con.println("Ingredients has been updated.");
					con.setColour(Color.white);
					break;
				case 3:
					UtilityInput.takeStringArray("IngredientsGuidance", toUpdateR.getIngredients().length);
					con.setColour(Color.green);
					con.println("Ingredients Guidance has been updated.");
					con.setColour(Color.white);
					break;
				case 4:
					UtilityInput.takeStringArray("MethodInstructions", toUpdateR.getIngredients().length);
					con.setColour(Color.green);
					con.println("Method Instructions has been updated.");
					con.setColour(Color.white);
					break;
				default:
					throw new Exception("Invalid Input.");
				}
			}
		} catch (Exception ex) {
			con.setColour(Color.red);
			con.println("Sorry! There are no " + type + "s saved to be updated.");
			con.setColour(Color.white);
		}
	}

	/*
	 * Updates every meal in the weekly menu. Takes details from user.
	 */
	protected static void setAllWeeklyList() {
		con.clear();
		if (!listOfRecipes.isEmpty()) {
			while (true) {
				try {
					int countDay = 0;
					int countRecipe = 0;
					Recipe[][] rArray = new Recipe[3][3];
					for (int i = 0; i < weeklyMenu.length; i++) {
						++countDay;
						for (int q = 0; q < weeklyMenu[0].length; q++) {
							++countRecipe;
							rArray[i][q] = UtilityInput.takeMeal(listOfRecipes, countDay, countRecipe);
							if (rArray[i][q] == null) {
								throw new Exception();
							}
						}
						countRecipe = 0;
					}
					WeeklyMenu.setRecipes(rArray);
					con.setColour(Color.green);
					con.println("\nThe Weekly Menu has been Successfully set.");
					con.setColour(Color.white);
					return;
				} catch (Exception ex) {
					con.setColour(Color.red);
					con.println("Sorry! That input was invalid. Please try again!");
					con.setColour(Color.white);
				}
			}
		} else {
			con.setColour(Color.red);
			con.println("\nSorry, there are no recipes saved to manipulate the weekly menu.");
			con.setColour(Color.white);
		}
	}

	/*
	 * Updates every meal in the weekly menu. Takes details from user.
	 */
	protected static void updateAllMeals() {
		con.clear();
		if (!listOfRecipes.isEmpty()) {
			while (true) {
				try {
					con.print("Taking the day to be updated:\nMonday = 1, Tuesday = 2, etc.\nEnter Selection:");
					int dayToBeUpdated = UtilityInput.takeIntFromConsole();
					if (dayToBeUpdated > 0 && dayToBeUpdated < 8) {
						int countRecipe = 0;
						for (Recipe r : weeklyMenu[dayToBeUpdated]) {
							++countRecipe;
							r = UtilityInput.takeMeal(listOfRecipes, dayToBeUpdated, countRecipe);
							if (r == null) {
								throw new Exception();
							}
						}
						con.setColour(Color.green);
						con.println("\nThe Meals have been Updated Successfully.");
						con.setColour(Color.white);
						return;
					}
					throw new Exception();
				} catch (Exception ex) {
					con.setColour(Color.red);
					con.println("\nSorry! That input was invalid. Please try again!");
					con.setColour(Color.white);
				}
			}
		} else {
			con.setColour(Color.red);
			con.println("\nSorry, there are no recipes saved to manipulate the weekly menu.");
			con.setColour(Color.white);
		}
	}

	/*
	 * Updates one meal in the weekly menu. Takes details from user.
	 */
	protected static void updateOneMeal() {
		con.clear();
		if (!listOfRecipes.isEmpty()) {
			while (true) {
				try {
					con.print("Taking the day to be updated:\nMonday = 1, Tuesday = 2, etc.\nEnter Selection:");
					int dayToBeUpdated = UtilityInput.takeIntFromConsole();
					con.print("Taking the meal to be updated:\nStarter = 1, Main = 2, Dessert = 3\nEnter Selection:");
					int mealToBeUpdated = UtilityInput.takeIntFromConsole();
					if (dayToBeUpdated > 0 && dayToBeUpdated < 8 && mealToBeUpdated > 0 && mealToBeUpdated < 4) {
						UtilityInput.takeMeal(listOfRecipes, dayToBeUpdated, mealToBeUpdated);
						con.setColour(Color.green);
						con.println("\nThe Meal has been Updated Successfully.");
						con.setColour(Color.white);
						return;
					}
					throw new Exception();
				} catch (Exception ex) {
					con.setColour(Color.red);
					con.println("\nSorry! That input was invalid. Please try again!");
					con.setColour(Color.white);
				}
			}
		} else {
			con.setColour(Color.red);
			con.println("\nSorry, there are no recipes saved to manipulate the weekly menu.");
			con.setColour(Color.white);
		}
	}
}
