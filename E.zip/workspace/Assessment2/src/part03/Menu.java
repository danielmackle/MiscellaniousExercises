package part03;
public class Menu {
	private String items[];
	private String title;

	public Menu(String title, String data[]) {
		this.title = title;
		this.items = data;
	}

	private void display() {
		QUBVisualKitchen.con.println(title);
		for (int count = 0; count < title.length(); count++) {
			QUBVisualKitchen.con.print("+");
		}
		QUBVisualKitchen.con.println();
		for (int option = 1; option <= items.length; option++) {
			QUBVisualKitchen.con.println(option + ". " + items[option - 1]);
		}
		QUBVisualKitchen.con.println();
	}

	public int getUserChoice() {
		display();
		QUBVisualKitchen.con.print("Enter Selection:");
		int value = UtilityInput.takeIntFromConsole();
		return value;
	}
}
