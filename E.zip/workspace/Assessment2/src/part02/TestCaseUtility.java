package part02;

import part01.FOODTYPE;
import part01.Utility;

public class TestCaseUtility extends TestCases 
{
	public static void testCases(int selection) {
		switch (selection) {
		case (32):
			testCase32();
		break;
		case (33):
			testCase33();
		break;
		case (34):
			testCase34();
		break;
		case (35):
			testCase35();
		break;
		case (36):
			testCase36();
		break;
		case (37):
			testCase37();
		break;
		case (38):
			testCase38();
		break;
		case (39):
			testCase39();
		break;
		case (40):
			testCase40();
		break;
		case (48):
			testCase40();
		break;
		case (41):
			testCase41();
		break;
		case (42):
			testCase42();
		break;
		case (43):
			testCase43();
		break;
		case (49):
			testCase43();
		break;
		}
	}

	public static void testCase32() {
		try {
			testCaseStart(32, "Utility Management", "Attemptying int validation with a positive int input.");
			
			Utility.validatePositiveInt(1);
			
			System.out.print("\nOutput:\n");
			System.out.println("The input is valid.");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("The input is invalid");
		}
	}
	
	public static void testCase33() {
		try {
			testCaseStart(33, "Utility Management", "Attemptying int validation with a negative int input.");
			
			System.out.print("\nOutput:\n");
			Utility.validatePositiveInt(-1);
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("The input is invalid");
		}
	}
	
	public static void testCase34() {
		try {
			testCaseStart(34, "Utility Management", "Attemptying float validation with a positive float input.");
			float f =9;
			Utility.validatePositiveFloat(f);
			
			System.out.print("\nOutput:\n");
			System.out.println("The input is valid.");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("The input is invalid");
		}
	}
	
	public static void testCase35() {
		try {
			testCaseStart(35, "Utility Management", "Attemptying float validation with a negative float input.");
			float f = -7;
			
			System.out.print("\nOutput:\n");
			Utility.validatePositiveFloat(f);
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("The input is invalid");
		}
	}
	
	public static void testCase36() {
		try {
			testCaseStart(36, "Utility Management", "Attemptying Food Type validation with an erroneous Food Type input.");
			
			Utility.validateFOODTYPE(FOODTYPE.ERRORNEOUS);
			
			System.out.print("\nOutput:\n");
			System.out.println("The input is valid.");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("The input is invalid");
		}
	}
	
	public static void testCase37() {
		try {
			testCaseStart(37, "Utility Management", "Attemptying Food Type validation with a valid Food Type input.");
			
			System.out.print("\nOutput:\n");
			Utility.validateFOODTYPE(FOODTYPE.PROTEIN);
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("The input is invalid");
		}
	}
	
	public static void testCase38() {
		try {
			testCaseStart(38, "Utility Management", "Sorting Ingredient by Name ascending.");
			
			createPremadeIngredients();
			
			Utility.sortList(listOfIngredients,null,true,"Ingredient");
			
			System.out.print("\nOutput:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("The input is invalid");
		}
	}
	
	public static void testCase39() {
		try {
			testCaseStart(39, "Utility Management", "Sorting Ingredient by Name descending.");
			
			createPremadeIngredients();
			
			Utility.sortList(listOfIngredients,null,false,"Ingredient");
			
			System.out.print("\nOutput:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("The input is invalid");
		}
	}
	
	public static void testCase40() {
		try {
			testCaseStart(40, "Utility Management", "Sorting Ingredient by Name ascending in null list.");
			
			Utility.sortList(listOfIngredients,null,true,"Ingredient");
			
			System.out.print("\nOutput:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}
	public static void testCase41() {
		try {
			testCaseStart(41, "Utility Management", "Sorting Recipe by Name ascending.");
			
			createPremadeRecipes();
			Utility.sortList(null,listOfRecipes,true,"Recipe");
			
			System.out.print("\nOutput:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}
	
	public static void testCase42() {
		try {
			testCaseStart(42, "Utility Management", "Sorting Recipe by Name descending.");
			
			createPremadeRecipes();
			Utility.sortList(null,listOfRecipes,false,"Recipe");
			
			System.out.print("\nOutput:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}
	
	public static void testCase43() {
		try {
			testCaseStart(43, "Utility Management", "Sorting Recipe by Name ascending in null list.");
			
			Utility.sortList(null,listOfRecipes,true,"Recipe");
			
			System.out.print("\nOutput:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}
}
