package part02;

import part01.FOODTYPE;
import part01.Ingredient;

public class TestCaseIngredient extends TestCases {
	public static void testCases(int selection) {
		switch (selection) {
		case (1):
			testCase1();
			break;
		case (2):
			testCase2();
			break;
		case (3):
			testCase3();
			break;
		case (44):
			testCase3();
			break;
		case (4):
			testCase4();
			break;
		case (5):
			testCase5();
			break;
		case (45):
			testCase5();
			break;
		case (6):
			testCase6();
			break;
		case (7):
			testCase7();
			break;
		case (8):
			testCase8();
			break;
		case (9):
			testCase9();
			break;
		case (10):
			testCase10();
			break;
		case (11):
			testCase11();
			break;
		case (12):
			testCase12();
			break;
		case (13):
			testCase13();
			break;
		}
	}

	public static void testCase1() {
		try {
			testCaseStart(1, "Ingredient Management", "Adding an ingredient with all valid values.");
			createPremadeIngredient();
			System.out.print("\nOutput:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}

	public static void testCase2() {
		try {
			testCaseStart(2, "Ingredient Management", "Adding an ingredient with null name.");
			System.out.println("Input: Name-null FoodType-FoodType.PROTEIN CaloriesPer100Grams-120");
			Ingredient toAdd = new Ingredient(null, FOODTYPE.PROTEIN, 120);
			listOfIngredients.add(toAdd);
			System.out.print("\nOutput:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}

	public static void testCase3() {
		try {
			testCaseStart(3, "Ingredient Management", "Adding an ingredient with extremely long name.");
			System.out.println(
					"Input: Name-eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee\nFoodType-FoodType.PROTEIN\nCaloriesPer100Grams-120");
			Ingredient toAdd = new Ingredient(
					"eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", FOODTYPE.PROTEIN,
					120);
			listOfIngredients.add(toAdd);
			System.out.print("\nOutput:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}

	public static void testCase4() {
		try {
			testCaseStart(4, "Ingredient Management", "Adding an ingredient with errorneous food type.");
			System.out.println("Input:\nName-Beef\nFoodType-FoodType.PROTEIN\nCaloriesPer100Grams-120");
			Ingredient toAdd = new Ingredient("Beef", FOODTYPE.ERRORNEOUS, 120);
			listOfIngredients.add(toAdd);
			System.out.print("\nOutput:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}

	public static void testCase5() {
		try {
			testCaseStart(5, "Ingredient Management", "Adding an ingredient with null food type.");
			System.out.println("Input:\nName-Beef\nFoodType-null\nCaloriesPer100Grams-120");
			Ingredient toAdd = new Ingredient("Beef", null, 120);
			listOfIngredients.add(toAdd);
			System.out.print("\nOutput:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}

	public static void testCase6() {
		try {
			testCaseStart(6, "Ingredient Management", "Adding an ingredient with valid CaloriesPer100Grams.");
			System.out.println("Input:\nName-Beef\nFoodType-FoodType.Protein\nCaloriesPer100Grams- 100");
			Ingredient toAdd = new Ingredient("Beef", FOODTYPE.PROTEIN, -1);
			listOfIngredients.add(toAdd);
			System.out.print("\nOutput:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}

	public static void testCase7() {
		try {
			testCaseStart(7, "Ingredient Management",
					"Adding an ingredient with excessively positive CaloriesPer100Grams.");
			System.out.println("Input:\nName-Beef\nFoodType-FoodType.Protein\nCaloriesPer100Grams- 999999999");
			Ingredient toAdd = new Ingredient("Beef", FOODTYPE.PROTEIN, 999999999);
			listOfIngredients.add(toAdd);
			System.out.print("\nOutput:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
			ex.printStackTrace();
		}
	}

	public static void testCase8() {
		try {
			testCaseStart(8, "Ingredient Management",
					"Adding an ingredient with excessively negative CaloriesPer100Grams.");
			System.out.println("Input:\nName-Beef\nFoodType-FoodType.Protein\nCaloriesPer100Grams- -999999999");
			Ingredient toAdd = new Ingredient("Beef", FOODTYPE.PROTEIN, -999999999);
			listOfIngredients.add(toAdd);
			System.out.print("\nOutput:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}
	
	public static void testCase9() {
		try {
			testCaseStart(9, "Ingredient Management", "Viewing all ingredients in a premade list.");
			System.out.println("Viewing an ingredient.");
			createPremadeIngredient();

			System.out.print("\nOutput:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}

	public static void testCase10() {
		try {
			testCaseStart(10, "Ingredient Management", "Viewing all ingredients in an empty list.");
			System.out.println("Viewing an ingredient.");

			System.out.print("\nOutput:\n");
			viewAllObject("Ingredient");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}
	public static void testCase11() {
		try {
			testCaseStart(11, "Ingredient Management", "Fetching Ingredient from ID.");
			createPremadeIngredient();

			System.out.print("\nOutput:\n");
			System.out.println(Ingredient.getIngredientFromID(0,listOfIngredients).toString());
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}
	public static void testCase12() {
		try {
			testCaseStart(12, "Ingredient Management", "Fetching Ingredient from erroneous ID.");
			createPremadeIngredient();

			System.out.print("\nOutput:\n");
			System.out.println(Ingredient.getIngredientFromID(-6,listOfIngredients).toString());
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}
	public static void testCase13() {
		try {
			testCaseStart(13, "Ingredient Management", "Fetching Ingredient from ID in null list.");

			System.out.print("\nOutput:\n");
			System.out.println(Ingredient.getIngredientFromID(0,listOfIngredients).toString());
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}
}
