package part02;

import part01.Ingredient;
import part01.Recipe;

public class TestCaseRecipe extends TestCases {
	public static void testCases(int selection) {
		switch (selection) {
		case (14):
			testCase14();
			break;
		case (15):
			testCase15();
			break;
		case (16):
			testCase16();
			break;
		case (46):
			testCase16();
			break;
		case (17):
			testCase17();
			break;
		case (18):
			testCase18();
			break;
		case (19):
			testCase19();
			break;
		case (20):
			testCase20();
			break;
		case (21):
			testCase21();
			break;
		case (22):
			testCase22();
			break;
		case (47):
			testCase22();
			break;
		case (23):
			testCase23();
			break;
		case (24):
			testCase24();
			break;
		case (25):
			testCase25();
			break;
		case (26):
			testCase26();
			break;
		case (27):
			testCase27();
			break;
		}
	}

	public static void testCase14() {
		try {
			testCaseStart(14, "Recipe Management", "Adding a Recipe with all valid values.");
			createPremadeRecipe();
			System.out.print("\nOutput:\n");
			viewAllObject("Recipe");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}

	public static void testCase15() {
		try {
			testCaseStart(15, "Recipe Management", "Adding a Recipe with a null name.");

			createPremadeIngredient();
			System.out.println(
					"Input:\nName- null\nIngredients: [Beef]\nIngredients Guidance-'100 grams'\nRecipe Instructions - 'Seperate then fry'");
			Recipe toAdd = new Recipe();
			toAdd = new Recipe(null, new Ingredient[] { listOfIngredients.get(0) }, new String[] { "100 grams" },
					new String[] { "Seperate then Fry" },new int[] {100});
			listOfRecipes.add(toAdd);

			System.out.print("\nOutput:\n");
			viewAllObject("Recipe");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}

	public static void testCase16() {
		try {
			testCaseStart(16, "Recipe Management", "Adding a Recipe with an extremely long name.");

			createPremadeIngredient();
			System.out.println(
					"Input:\nName-'Beef Stewwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww'\nIngredients: [Beef]\nIngredients Guidance-'100 grams'\nRecipe Instructions - 'Seperate then fry'");
			Recipe toAdd = new Recipe();
			toAdd = new Recipe(
					"Beef Stewwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww",
					new Ingredient[] { listOfIngredients.get(0) }, new String[] { "100 grams" },
					new String[] { "Seperate then Fry" },new int[] {100});
			listOfRecipes.add(toAdd);

			System.out.print("\nOutput:\n");
			viewAllObject("Recipe");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}

	public static void testCase17() {
		try {
			testCaseStart(17, "Recipe Management", "Adding a Recipe with one null Ingredient.");

			listOfIngredients.add(null);
			System.out.println(
					"Input:\nName-'Beef Stew'\nIngredients: [null]\nIngredients Guidance-'100 grams'\nRecipe Instructions - 'Seperate then fry'");
			Recipe toAdd = new Recipe();
			toAdd = new Recipe("Beef Stew", new Ingredient[] { listOfIngredients.get(0) }, new String[] { "100 grams" },
					new String[] { "Seperate then Fry" },new int[] {100});
			listOfRecipes.add(toAdd);

			System.out.print("\nOutput:\n");
			viewAllObject("Recipe");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}

	public static void testCase18() {
		try {
			testCaseStart(18, "Recipe Management", "Adding a Recipe with a null ingredients guidance.");

			System.out.println(
					"Input:\nName-'Beef Stew'\nIngredients: [Beef]\nIngredients Guidance- null\nRecipe Instructions - 'Seperate then fry'");
			Recipe toAdd = new Recipe();
			toAdd = new Recipe("Beef Stew", new Ingredient[] { listOfIngredients.get(0) }, null,
					new String[] { "Seperate then Fry" },new int[] {100});
			listOfRecipes.add(toAdd);

			System.out.print("\nOutput:\n");
			viewAllObject("Recipe");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}

	public static void testCase19() {
		try {
			testCaseStart(19, "Recipe Management", "Adding an Recipe with a null Recipe Instructions.");

			System.out.println(
					"Input:\nName-'Beef Stew'\nIngredients: [Beef]\nIngredients Guidance- '100 grams'\nRecipe Instructions - null");
			Recipe toAdd = new Recipe();
			toAdd = new Recipe("Beef Stew", new Ingredient[] { listOfIngredients.get(0) }, new String[] { "100 grams" },
					null,new int[] {100});
			listOfRecipes.add(toAdd);

			System.out.print("\nOutput:\n");
			viewAllObject("Recipe");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}

	public static void testCase20() {
		try {
			testCaseStart(20, "Recipe Management", "Adding a Recipe with two Ingredients.");

			createPremadeIngredient();
			createPremadeIngredient();
			System.out.println(
					"Input:\nName-'Beef Stew'\nIngredients: [Beef, Beef]\nIngredients Guidance-'100 grams'\nRecipe Instructions - 'Seperate then fry'");
			Recipe toAdd = new Recipe();
			toAdd = new Recipe("Beef Stew", new Ingredient[] { listOfIngredients.get(0), listOfIngredients.get(1) },
					new String[] { "100 grams" }, new String[] { "Seperate then Fry" },new int[] {100});
			listOfRecipes.add(toAdd);

			System.out.print("\nOutput:\n");
			viewAllObject("Recipe");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}

	public static void testCase21() {
		try {
			testCaseStart(21, "Recipe Management", "Deleting all Recipes with a premade list.");
			createPremadeRecipe();

			System.out.println("Deleting all Recipes.");
			deleteAllObject("Recipe");

			System.out.print("\nOutput:\n");
			viewAllObject("Recipe");

			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}

	public static void testCase22() {
		try {
			testCaseStart(22, "Recipe Management", "Deleting all Recipes with an empty list.");

			System.out.println("Deleting all Recipes.");
			deleteAllObject("Recipe");

			System.out.print("\nOutput:\n");
			viewAllObject("Recipe");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}

	public static void testCase23() {
		try {
			testCaseStart(23, "Recipe Management", "Viewing all Recipes in a premade list.");
			System.out.println("Viewing all Recipes.");

			System.out.print("\nOutput:\n");
			viewAllObject("Recipe");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}

	public static void testCase24() {
		try {
			testCaseStart(24, "Recipe Management", "Viewing all Recipes in an empty list.");
			System.out.println("Viewing all Recipes.");

			System.out.print("\nOutput:\n");
			viewAllObject("Recipe");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}
	
	public static void testCase25() {
		try {
			testCaseStart(25, "Recipe Management", "Fetching Recipe from ID.");
			createPremadeRecipe();

			System.out.print("\nOutput:\n");
			System.out.println(Recipe.getRecipeFromID(0,listOfRecipes).toString());
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}
	public static void testCase26() {
		try {
			testCaseStart(26, "Recipe Management", "Fetching Recipe from erroneous ID.");
			createPremadeRecipe();

			System.out.print("\nOutput:\n");
			System.out.println(Recipe.getRecipeFromID(-9,listOfRecipes).toString());
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}
	public static void testCase27() {
		try {
			testCaseStart(27, "Recipe Management", "Fetching Recipe from ID in null list.");

			System.out.print("\nOutput:\n");
			System.out.println(Recipe.getRecipeFromID(0,listOfRecipes).toString());
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}
}
