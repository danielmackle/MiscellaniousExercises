/**
 * @author Daniel Mackle
 * @id 40407187
 * @date 22/11/2023
 */
package part01;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Used to perform common inputs based methods of data to save lines.
 */
public abstract class UtilityInput {
	/**
	 * Used to take input from System.in Will not close until
	 */
	public static Scanner input = new Scanner(System.in);

	/**
	 * Asks for, inputs and validates a string input from Scanner
	 */
	public static String takeStringFromScanner() {
		try {
			return (String) input.next();
		} catch (Exception exception) {
			return "ERROR";
		}
	}

	/**
	 * Asks for, inputs and validates an int input from Scanner
	 */
	public static int takeIntFromScanner() {
		try {
			return Integer.parseInt(input.next());
		} catch (Exception exception) {
			return -1;
		}
	}

	/**
	 * Asks for, inputs and validates a float input from Scanner
	 */
	public static float takeFloatFromScanner() {
		try {
			return Float.parseFloat(input.next());
		} catch (Exception exception) {
			return -1;
		}
	}

	public static boolean takeBooleanFromScanner() throws Exception {
		String selection = (String) input.next();
		if (selection.equals("y")) {
			return true;
		} else if (selection.equals("n")) {
			return false;
		} else {
			throw new Exception();
		}
	}

	/**
	 * Asks for, inputs and validates an existing Ingredient from Scanner
	 * 
	 * @param ArrayList<Ingredient> 'listOfIngredients' - holds the existing list of
	 *                              ingredients to find the selected ingredient.
	 * @return Ingredient - output of found ingredient
	 */
	public static Ingredient takeIngredient(ArrayList<Ingredient> listOfIngredients) throws Exception{
		if (listOfIngredients.isEmpty()) {
			throw new ArithmeticException();
		}
		while (true) {
			try {
				
				System.out.println(
						"Sorting Ingredients by Name:");
				System.out.print("\nSort by ascending?\nPlease type 'y' or 'n':");
				boolean ascending = UtilityInput.takeBooleanFromScanner();
				Utility.sortList(listOfIngredients,null, ascending,"Ingredient");
				System.out.println();
				Utility.ListArrayToStringShort(listOfIngredients);
				System.out.println();
				boolean valid=false;
				while(!valid) {
					ArrayList<Ingredient> ings = Utility.searchIngredientList(listOfIngredients);
					if(!ings.isEmpty()) {
						valid=true;
						System.out.println();
						for(Ingredient i : ings) {
							i.toStringShort();
						}
					}
					else {
						System.out.println("Sorry! No Ingredient under that name was found. Try again!");
					}
				}
				System.out.println();
				while (true) {
					int id = UtilityInput.takeID("Ingredient");
					for (Ingredient i : listOfIngredients) {
						if (id == i.getIngredientID()) {
							return i;
						}
						System.out.println("Sorry, the Ingredient was not found. Please try again!");
					}
				}
			} catch (Exception ex) {
				System.out.println("\nSorry, an input was invalid. Please Try Again!");
			}
		}
	}

	/**
	 * Asks for, inputs and validates an existing Recipe from Scanner
	 * 
	 * @param ArrayList<Recipe> 'listOfRecipes' - holds the existing list of
	 *                              recipes to find the selected ingredient
	 * @return Recipe - output of found recipe
	 */
	public static Recipe takeRecipe(ArrayList<Recipe> listOfRecipes) throws Exception{
		if (listOfRecipes.isEmpty()) {
			throw new ArithmeticException();
		}
		while (true) {
			try {
				
				System.out.println(
						"Sorting Recipes by Name:");
				System.out.print("\nSort by ascending?\nPlease type 'y' or 'n':");
				boolean ascending = UtilityInput.takeBooleanFromScanner();
				Utility.sortList(null,listOfRecipes, ascending,"Recipe");
				System.out.println();
				Utility.ListArrayToStringShortR(listOfRecipes);
				System.out.println();
				boolean valid=false;
				while(!valid) {
					ArrayList<Recipe> recs = Utility.searchRecipeList(listOfRecipes);
					if(!recs.isEmpty()) {
						valid=true;
						System.out.println();
						for(Recipe r : recs) {
							r.toStringShort();
						}
					}
					else {
						System.out.println("Sorry! No Recipe under that name was found. Try again!");
					}
				}
				System.out.println();
				while (true) {
					int id = UtilityInput.takeID("Recipe");
					for (Recipe r : listOfRecipes) {
						if (id == r.getRecipeID()) {
							return r;
						}
						System.out.println("Sorry, the Recipe was not found. Please try again!");
					}
				}
			} catch (Exception ex) {
				System.out.println("\nSorry, an input was invalid. Please Try Again!");
			}
		}
	}

	/**
	 * Asks for, inputs and validates an existing Ingredient from Scanner
	 * 
	 * @param String 'type' - Used to tell between method calls
	 * @return Recipe - output of found recipe
	 */
	public static int takeID(String type) throws Exception {

		while (true) {
			System.out.print("Please enter ID of " + type + ":");
			int id = UtilityInput.takeIntFromScanner();
			if (id >= 0) {
				return id;
			} else {
				System.out.println("\nSorry, that ID was invalid. Please try Again!\n");
			}
		}
	}

	/**
	 * Takes String input and validates whether it is valid or invalid.
	 */
	public static String takeName() {
		String name;
		while (true) {
			System.out.print("\nAdding a Name:\nPlease Enter a Name:");
			name = UtilityInput.takeStringFromScanner();
			if (name != "ERROR") {
				return name;
			} else {
				System.out.println("\nSorry, that input was invalid. Please try Again!\n");
			}
		}
	}

	/**
	 * Takes FoodType input and validates whether it is valid or invalid.
	 */
	public static FOODTYPE takeFoodType() {
		while (true) {
			System.out.print(
					"\nAdding a Food Type:\n1: Dairy\n2: Cereal\n3: Fruit & Veg\n4: Protein\n5: Sugar\n6: Fat\n7: Composite Food\n8: Spice & Herb\n9: Essential Nutrient\nPlease Enter Selection:");
			int index = UtilityInput.takeIntFromScanner();
			switch (index) {
			case (1):
				return FOODTYPE.DAIRY;
			case (2):
				return FOODTYPE.CEREAL;
			case (3):
				return FOODTYPE.FRUITANDVEG;
			case (4):
				return FOODTYPE.PROTEIN;
			case (5):
				return FOODTYPE.SUGAR;
			case (6):
				return FOODTYPE.FAT;
			case (7):
				return FOODTYPE.COMPOSITEFOOD;
			case (8):
				return FOODTYPE.SPICEANDHERB;
			case (9):
				return FOODTYPE.ESSENTIALNUTRIENT;
			default:
				System.out.println("\nSorry, that input was invalid. Please try Again!\n");
			}
		}
	}

	/**
	 * Takes float input and validates whether it is valid or invalid.
	 */
	public static float takeCaloriesPer100Grams() {
		float caloriesPer100Grams;
		while (true) {
			System.out.print("\nAdding the Caloric Details:\nPlease enter the Calories per 100 grams:");
			caloriesPer100Grams = UtilityInput.takeFloatFromScanner();
			if (caloriesPer100Grams != -1) {
				return caloriesPer100Grams;
			} else {
				System.out.println("\nSorry, that input was invalid. Please try Again!\n");
			}
		}
	}

	/**
	 * Asks for, inputs and validates an existing Ingredient array from Scanner
	 * 
	 * @param ArrayList<Ingredient> 'listOfIngredients' - holds the existing list of
	 *                              ingredients to find the selected ingredient.
	 * @return Ingredient[] - output of found ingredieng array
	 */
	public static Ingredient[] takeIngredients(ArrayList<Ingredient> listOfIngredients) {
		while (true) {
			try {
				System.out.print("\nSelecting the Ingredients:\nPlease enter the number of Ingredient Types to Add:");
				int amountOfIngredients = UtilityInput.takeIntFromScanner();
				Ingredient[] ingredients = new Ingredient[amountOfIngredients];
				for (int i = 0; i < amountOfIngredients; i++) {
					System.out.println("\nIngredient " + (i + 1) + ":");
					ingredients[i] = UtilityInput.takeIngredient(listOfIngredients);
				}
				return ingredients;
			} catch (Exception ex) {
				System.out.println("\nSorry, that Ingredient was invalid. Please try Again!\n");
			}
		}
	}

	/**
	 * Asks for, inputs and validates an existing Ingredient array from Scanner
	 * 
	 * @param String 'type' - Used to tell between method calls
	 * @param int    'amountOfIngredients' - holds the amount of ingredients to have
	 *               a string taken for
	 * @return String[] - output of taken String array
	 */
	public static String[] takeStringArray(String type, int amountOfIngredients) {
		while (true) {
			try {
				switch (type) {
				case ("IngredientsGuidance"):
					System.out.println("\nSelecting the Ingredients Guidance:");
					String[] ingredientsGuidance = new String[amountOfIngredients];
					for (int i = 0; i < amountOfIngredients; i++) {
						System.out.print("Ingredient Guidance " + (i + 1) + ":");
						ingredientsGuidance[i] = UtilityInput.takeStringFromScanner();
					}
					return ingredientsGuidance;
				case ("MethodInstructions"):
					System.out.println("\nSelecting the Method Instructions:");
					String[] recipeInstructions = new String[amountOfIngredients];
					for (int i = 0; i < amountOfIngredients; i++) {
						System.out.print("Recipe Instruction " + (i + 1) + ":");
						recipeInstructions[i] = UtilityInput.takeStringFromScanner();
					}
					return recipeInstructions;
				}
			} catch (Exception ex) {
				System.out.println("\nSorry, that " + type + " was invalid. Please try Again!\n");
			}
		}
	}

	/**
	 * Asks for, inputs and validates an existing Ingredient array from Scanner
	 * 
	 * @param String 'type' - Used to tell between method calls
	 * @param int    'amountOfIngredients' - holds the amount of ingredients to have
	 *               a string taken for
	 * @return String[] - output of taken String array
	 */
	public static Recipe takeMeal(ArrayList<Recipe> listOfRecipes, int countDay, int countRecipe) {
		while(true) {
			try {
				System.out.println("Day: " + countDay + ", Meal: " + countRecipe);
				Recipe r = UtilityInput.takeRecipe(listOfRecipes);
				if (r == null) {
					throw new Exception();
				}
				return r;
			}
			catch(Exception ex) {}
		}
	}

	public static int[] takeIntArray(int length) {
		while (true) {
			try {
				System.out.println("\nSelecting amount (in grams):");
				int[] ingredientsGuidance = new int[length];
				for (int i = 0; i < length; i++) {
					System.out.print("Amount in grams of Ingredient " + (i + 1) + ":");
					ingredientsGuidance[i] = UtilityInput.takeIntFromScanner();
				}
				return ingredientsGuidance;
			} catch (Exception ex) {
				System.out.println("\nSorry, that number was invalid. Please try Again!\n");
			}
		}
	}
}
