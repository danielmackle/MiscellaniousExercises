/**
 * @author Daniel Mackle
 * @id 40407187
 * @date 11/11/2023
 */
package part01;

import java.util.ArrayList;

/**
 * Used to perform common misc. manipulations of data to save lines.
 */
public abstract class Utility {
	/**
	 * Takes int ID input and validates whether it is valid or invalid. ID starts at
	 * 0.
	 * 
	 * @param int 'ID' - Identification integer input
	 * @return boolean - True for pass, False for Fail
	 */
	public static boolean validatePositiveInt(int ID) {
		try {
			if (ID < 0 | ID > 2147483647) {
				throw new IllegalArgumentException("Integer outside boundaries.");
			}
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * Takes float input and validates whether it is valid or invalid.
	 * 
	 * @param int 'ID' - Identification integer input
	 * @return boolean - True for pass, False for Fail
	 */
	public static boolean validatePositiveFloat(float ID) {
		try {
			if (ID < 0 | ID > 2147483647) {
				throw new IllegalArgumentException("Float outside boundaries.");
			}
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * Takes FOODTYPE and validates whether it is erroneous.
	 * 
	 * @param enum FOODTYPE 'FOODTYPE'
	 * @return boolean - True for pass, False for Fail
	 */
	public static boolean validateFOODTYPE(FOODTYPE FOODTYPE) {
		try {
			if (FOODTYPE == part01.FOODTYPE.ERRORNEOUS) {
				throw new IllegalArgumentException(FOODTYPE.toString());
			}
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * Takes String input and validates whether it is erroneous.
	 * 
	 * @param String 'string'
	 * @return boolean - True for pass, False for Fail
	 */
	public static boolean validateString(String stringToValidate) {
		try {
			if (stringToValidate == "") {
				throw new IllegalArgumentException("String is Null");
			}
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * Takes String Array and outputs as a single String.
	 * 
	 * @param String[] 'stringArray'
	 * @return String - String output representing all Strings in the Array
	 */
	public static String stringArrayToString(String[] stringArray) {
		String response = "";
		for (String string : stringArray) {
			response += string;
		}
		return response;
	}

	/**
	 * Takes Object Array input and and outputs as a single String representation.
	 * 
	 * @param Ingredient[] 'ingredientArray'
	 * @return boolean - False for pass, True for Fail
	 */
	public static String objectArrayToString(Object[] objectArray) {
		String response = "";
		for (Object object : objectArray) {
			response += object.toString();
		}
		return response;
	}

	/**
	 * Takes 2DArray input and and outputs as a single String representation.
	 * 
	 * @param Ingredient[] 'ingredientArray'
	 * @return boolean - False for pass, True for Fail
	 */
	public static String recipe2DArrayToString(Recipe[][] recipe2DArray) {
		String response = "";
		for (Recipe[] recipe1DArray : recipe2DArray) {
			for (Recipe recipe : recipe1DArray) {
				response += recipe.toString();
			}
		}
		return response;
	}

	/**
	 * Exits program normally, with valid exit flag.
	 */
	public static void Exit() {
		System.out.println("\n");
		System.out.println("Happy to help! Closing now.");
		System.exit(0);
	}

	public static void collectionsSwapRipoff(ArrayList<Ingredient> list, int i, int j) {
		// let me use util.collections.swap pleeeeeaseeeee i beg
		Ingredient ing = list.get(i);
		list.set(i, list.get(j));
		list.set(j, ing);
	}

	public static void collectionsSwapRipoffR(ArrayList<Recipe> list, int i, int j) {
		Recipe r = list.get(i);
		list.set(i, list.get(j));
		list.set(j, r);
	}

	public static void sortList(ArrayList<Ingredient> listOfIngredients, ArrayList<Recipe> listOfRecipes,
			boolean ascending, String type) {
		try {
			switch (type) {
			case ("Ingredient"):
				if (listOfIngredients.size() == 0) {
					throw new ArithmeticException();
				}
				for (int q = 0; q < listOfIngredients.size() - 1; q++) {
					for (int i = 0; i < listOfIngredients.size() - 1; i++) {
						String name = listOfIngredients.get(i).getIngredientName();
						String nextName = listOfIngredients.get(i + 1).getIngredientName();
						boolean nasc = name.compareTo(nextName) > 0 && !ascending;
						boolean asc = name.compareTo(nextName) < 0 && ascending;
						if (nasc || asc) {
							collectionsSwapRipoff(listOfIngredients, i, i + 1);
						}
					}
				}
				break;
			case ("Recipe"):
				if (listOfRecipes.size() == 0) {
					throw new ArithmeticException();
				}
				for (int q = 0; q < listOfRecipes.size() - 1; q++) {
					for (int i = 0; i < listOfRecipes.size() - 1; i++) {
						String name = listOfRecipes.get(i).getRecipeName();
						String nextName = listOfRecipes.get(i + 1).getRecipeName();
						if (name.compareTo(nextName) > 0) {
							collectionsSwapRipoffR(listOfRecipes, i, i + 1);
						}
					}
				}
				break;
			}
		} catch (ArithmeticException ex) {
			System.out.println("\nSorry! There are no " + type + "s to be deleted.");
		} catch (Exception ex) {
			System.out.println("\nSorry! Sort has failed.");
		}
	}

	public static void ListArrayToStringShort(ArrayList<Ingredient> list) {
		for (Ingredient i : list) {
			i.toStringShort();
		}
	}

	public static ArrayList<Ingredient> searchIngredientList(ArrayList<Ingredient> listOfIngredients) {
		try {
			System.out.println("\nPlease enter part of the Ingredient name to be searched for:");
			if (listOfIngredients.isEmpty()) {
				throw new ArithmeticException();
			}
			ArrayList<Ingredient> hold = new ArrayList<Ingredient>();
			String pattern = UtilityInput.takeStringFromScanner();
			for(Ingredient i : listOfIngredients) {
				if(i.getIngredientName().contains(pattern)) {
					hold.add(i);
				}
			}
			return hold;
		} catch (ArithmeticException ex) {
			System.out.println("\nSorry! There are no Ingredients saved to be searched.");
		} catch (Exception ex) {
			System.out.println("\nSorry! Sort has failed.");
		}
		return null;
	}
	
	public static ArrayList<Recipe> searchRecipeList(ArrayList<Recipe> listOfRecipes) {
		try {
			System.out.println("\nPlease enter part of the Recipe name to be searched for:");
			if (listOfRecipes.isEmpty()) {
				throw new ArithmeticException();
			}
			ArrayList<Recipe> hold = new ArrayList<Recipe>();
			String pattern = UtilityInput.takeStringFromScanner();
			for(Recipe r : listOfRecipes) {
				if(r.getRecipeName().contains(pattern)) {
					hold.add(r);
				}
			}
			return hold;
		} catch (ArithmeticException ex) {
			System.out.println("\nSorry! There are no Recipes saved to be searched.");
		} catch (Exception ex) {
			System.out.println("\nSorry! Sort has failed.");
		}
		return null;
	}

	public static void ListArrayToStringShortR(ArrayList<Recipe> listOfRecipes) {
		for (Recipe r : listOfRecipes) {
			r.toStringShort();
		}
	}
}