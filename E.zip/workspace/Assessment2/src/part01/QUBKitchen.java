package part01;

import java.util.ArrayList;

public class QUBKitchen {
	/**
	 * Holds the created Ingredients across the entire program
	 */
	protected static ArrayList<Ingredient> listOfIngredients = new ArrayList<Ingredient>();
	/**
	 * Holds the created Recipes across the entire program
	 */
	protected static ArrayList<Recipe> listOfRecipes = new ArrayList<Recipe>();
	/**
	 * Holds the current Weekly Menu to be manipulated
	 */
	protected static Recipe[][] weeklyMenu = new Recipe[3][3];

	/**
	 * Entry point of the program - makes preset values and runs the main menu
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.print("Would you like to generate premade values for quick testing?");
		boolean valid = false;
		boolean generate = false;
		while (!valid) {
			try {
				generate = UtilityInput.takeBooleanFromScanner();
				valid = true;
			} catch (Exception ex) {
				System.out.println("Sorry! That input was not vaalid. Please try again.");
			}
		}
		if (generate) {
			try {
				setPresetValues();
				System.out.println("Premade values loaded.");
			} catch (Exception ex) {
				System.out.println("Error creating premade values.");
			}
		}
		mainMenu();
	}

	/**
	 * Sets preset values for easy testing. Wipes all previous data.
	 * 
	 * @throws Exception (but will never be thrown)
	 */
	public static void setPresetValues() throws Exception {
		listOfIngredients.clear();
		listOfRecipes.clear();
		weeklyMenu = new Recipe[3][3];
		listOfIngredients.add(new Ingredient("Beef", FOODTYPE.PROTEIN, 100));
		listOfIngredients.add(new Ingredient("Pork", FOODTYPE.PROTEIN, 300));
		listOfIngredients.add(new Ingredient("Potato", FOODTYPE.PROTEIN, 300));
		listOfRecipes.add(new Recipe("Beef Stew",
				new Ingredient[] { listOfIngredients.get(0), listOfIngredients.get(2) },
				new String[] { "Seperated", "Mashed" },
				new String[] { "1. Mash Potatoes", "2. Fry Beef in pan", "3. Use beef stock cubes", "4. Assemble" },new int[] {100,500}));
		listOfRecipes.add(new Recipe("Pork Stew",
				new Ingredient[] { listOfIngredients.get(2), listOfIngredients.get(2) },
				new String[] { "Cut into chunks", "Mashed" },
				new String[] { "1. Mash Potatoes", "2. Fry Pork in pan", "3. Use pork stock cubes", "4. Assemble" },new int[] {300,200}));
		weeklyMenu[0][0] = listOfRecipes.get(0);
		weeklyMenu[1][0] = listOfRecipes.get(1);
	}

	/**
	 * Displays the main menu which navigates the user to the more specified menuss
	 */
	protected static void mainMenu() {
		while (true) {
			try {
				Menu mainMenu = new Menu("Queen's University Belfast Kitchen",
						new String[] { "Manage Ingredients", "Manage Recipes", "Manage the Weekly Menu", "Exit" });
				switch (mainMenu.getUserChoice()) {
				case (1):
					// Manage Ingredients
					manageIngredientsMenu();
					break;
				case (2):
					// Manage Recipes
					manageRecipesMenu();
					break;
				case (3):
					// Manage the Weekly Menu
					manageWeeklyMenu();
					break;
				case (4):
					// Exit
					System.out.println("Happy to help! Closing now.");
					System.exit(0);
					break;
				}
			} catch (Exception ex) {
				System.out.println("\nSorry! That Selection was invalid. Please try again!\n");
			}
		}
	}

	/**
	 * Displays the menu which navigates the user to the functions involving
	 * ingredients
	 */
	private static void manageIngredientsMenu() {
		boolean valid = false;
		while (!valid) {
			try {
				System.out.println("");
				Menu ingredientMenu = new Menu("Manage Ingredients",
						new String[] { "Add an Ingredient Type", "Delete an Ingredient Type",
								"Delete all Ingredient Types", "View an Ingredient Type", "View all Ingredient Types",
								"Update an Ingredient Type", "Back" });
				switch (ingredientMenu.getUserChoice()) {
				case (1):
					// Add an Ingredient Type
					addObject("Ingredient");
					break;
				case (2):
					// Delete an Ingredient Type
					deleteObject("Ingredient");
					break;
				case (3):
					// Delete all Ingredient Types
					deleteAllObject("Ingredient");
					break;
				case (4):
					// View an Ingredient Type
					viewObject("Ingredient");
					break;
				case (5):
					// View all Ingredient Types
					viewAllObject("Ingredient");
					break;
				case (6):
					// Update an Ingredient Type
					updateObject("Ingredient");
					break;
				case (7):
					valid = true;
					break;
				default:
					throw new Exception();
				}
			} catch (Exception ex) {
				System.out.println("\nSorry! That Selection was invalid. Please try again!");
			}
		}
	}

	/**
	 * Displays the menu which navigates the user to the functions involving recipes
	 */
	private static void manageRecipesMenu() {
		boolean valid = false;
		while (!valid) {
			try {
				System.out.println("");
				Menu recipeMenu = new Menu("Manage Recipes", new String[] { "Add a Recipe", "Delete a Recipe",
						"Delete all Recipes", "View a Recipe", "View all Recipes", "Update a Recipe", "Back" });
				switch (recipeMenu.getUserChoice()) {
				case (1):
					// Add a Recipe
					addObject("Recipe");
					break;
				case (2):
					// Delete a Recipe
					deleteObject("Recipe");
					break;
				case (3):
					// Delete all Recipes
					deleteAllObject("Recipe");
					break;
				case (4):
					// View a Recipe
					viewObject("Recipe");
					break;
				case (5):
					// View all Recipes
					viewAllObject("Recipe");
					break;
				case (6):
					// Update a Recipe
					updateObject("Recipe");
					break;
				case (7):
					valid = true;
					break;
				default:
					throw new Exception();
				}
			} catch (Exception ex) {
				System.out.println("\nSorry! That Selection was invalid. Please try again!");
			}
		}
	}

	/**
	 * Displays the menu which navigates the user to the functions involving the
	 * weekly menu
	 */
	private static void manageWeeklyMenu() {
		boolean valid = false;
		while (!valid) {
			try {
				System.out.println("");
				Menu recipeMenu = new Menu("Manage the Weekly Menu",
						new String[] { "Set all Meals", "Update the Meals of a Day", "Update one Meal",
								"View Weekly Menu", "Clear Weekly Menu", "Back" });
				switch (recipeMenu.getUserChoice()) {
				case (1):
					// Fill Weekly Menu
					setAllWeeklyList();
					break;
				case (2):
					// Update a Day in the Weekly Menu
					updateAllMeals();
					break;
				case (3):
					// Update a Meal in the Weekly Menu
					updateOneMeal();
					break;
				case (4):
					// View Weekly Menu
					viewObject("WeeklyMenu");
					break;
				case (5):
					// Wipe the Weekly Menu
					deleteAllObject("WeeklyMenu");
					break;
				case (6):
					valid = true;
					break;
				default:
					throw new Exception();
				}
			} catch (Exception ex) {
				System.out.println("\nSorry! That Selection was invalid. Please try again!");
			}
		}
	}

	/**
	 * Takes the needed inputs and constructs either an ingredient or a recipe
	 * instance
	 * 
	 * @param type
	 */
	protected static void addObject(String type) {
		Ingredient toAddI;
		Recipe toAddR;
		try {
			switch (type) {
			case "Ingredient":
				// take details and construct
				System.out.println("Adding an Ingredient Type:");
				toAddI = new Ingredient(UtilityInput.takeName(), UtilityInput.takeFoodType(),
						UtilityInput.takeCaloriesPer100Grams());
				// save to list
				listOfIngredients.add(toAddI);
				System.out.println(toAddI.toString());
				break;
			case "Recipe":
				if (listOfIngredients.isEmpty()) {
					throw new ArithmeticException();
				}
				// take details
				System.out.println("Adding a Recipe Type:");
				String name = UtilityInput.takeName();
				Ingredient[] ingredients = UtilityInput.takeIngredients(listOfIngredients);
				String[] ingredientsGuidance = UtilityInput.takeStringArray("IngredientsGuidance", ingredients.length);
				String[] methodInstructions = UtilityInput.takeStringArray("MethodInstructions", ingredients.length);
				int[] grams = UtilityInput.takeIntArray(ingredients.length);
				// construct new recipe
				toAddR = new Recipe(name, ingredients, ingredientsGuidance, methodInstructions,grams);
				// save to list
				listOfRecipes.add(toAddR);
				System.out.println(toAddR.toString());
				break;
			}
		} catch (ArithmeticException imex) {
			System.out.println("\nSorry, there are no Ingredients saved to make a Recipe with.");
		} catch (Exception e) {
			System.out.println("\nSorry, an error has occurred in construction. Please try again.");
		}
	}

	/*
	 * Deletes a user-selected ingredient or recipe. Removes from
	 * listOfIngredients/listOfRecipes
	 */
	protected static void deleteObject(String type) {
		try {
			System.out.println("\nDeleting " + type + ":");
			switch (type) {
			case "Ingredient":
				Ingredient i = UtilityInput.takeIngredient(listOfIngredients);
				Ingredient.deleteIngredient(i, listOfIngredients);
				break;
			case "Recipe":
				Recipe r = UtilityInput.takeRecipe(listOfRecipes);
				if (r != null) {
					listOfRecipes.remove(r);
					System.out.println("\nThe Recipe has been deleted.");
				}
				break;
			}
		} catch (Exception ex) {
			System.out.println("\nSorry! There are no " + type + "s saved to be deleted.");
		}
	}

	/*
	 * Deletes all ingredients or recipes. Wipes listOfIngredients/listOfRecipes
	 */
	protected static void deleteAllObject(String type) {
		try {
			switch (type) {
			case ("Ingredient"):
				if (listOfIngredients.isEmpty()) {
					throw new Exception();
				}
				listOfIngredients.clear();
				break;
			case ("Recipe"):
				if (listOfRecipes.isEmpty()) {
					throw new Exception();
				}
				listOfRecipes.clear();
				break;
			case ("WeeklyMenu"):
				weeklyMenu = new Recipe[3][3];
				break;
			}
			System.out.println("\nAll " + type + "s have been deleted.");
		} catch (Exception ex) {
			System.out.println("\nSorry! There are no " + type + "s to be deleted.");
		}
	}

	/*
	 * Views a user-selected ingredient or recipe. Runs toString for the fetched
	 * object.
	 */
	protected static void viewObject(String type) {
		try {
			System.out.println("\nViewing Specific " + type + ":");
			switch (type) {
			case "Ingredient":
				if (listOfIngredients.isEmpty()) {
					throw new ArithmeticException();
				}
				System.out.println(
						"\nSelected Ingredient:\n" + UtilityInput.takeIngredient(listOfIngredients).toString());
				break;
			case "Recipe":
				if (listOfRecipes.isEmpty()) {
					throw new ArithmeticException();
				}
				System.out.println("\nSelected Recipe:\n" + UtilityInput.takeRecipe(listOfRecipes).toString());
				break;
			case "WeeklyMenu":
				for (int i = 0; i < 4; i++) {
					for (int q = 0; q < 4; q++) {
						System.out.println("Day: " + i + " Meal:" + q);
						try {
							weeklyMenu[i][q].toStringShort();
						} catch (Exception ex) {
							System.out.println("Sorry! This menu item is not yet confirmed\n");
						}

					}
				}
				break;
			}
		} catch (ArithmeticException ex) {
			System.out.println("\nSorry, there are no " + type + "s saved to view.");
		} catch (Exception ex) {
		}
	}

	/*
	 * Views all user-selected ingredient or recipe. Runs toString for all fetched
	 * objects.
	 */
	protected static void viewAllObject(String type) {
		// todo display all sorted recipes short
		System.out.println("\nViewing all " + type + "s:");
		switch (type) {
		case ("Recipe"): {
			if (!listOfRecipes.isEmpty()) {
				int count = 0;
				for (Recipe r : listOfRecipes) {
					System.out.print("Recipe " + ++count + ":\n" + r.toString());
				}
			} else {
				System.out.println("\nSorry, there are no " + type + "s saved to view.");
			}
			break;
		}
		case ("Ingredient"): {
			if (!listOfIngredients.isEmpty()) {
				int count = 0;
				for (Ingredient i : listOfIngredients) {
					System.out.println("Ingredient " + ++count + ":\n" + i.toString() + "\n");
				}
			} else {
				System.out.println("\nSorry, there are no " + type + "s saved to view.");
			}
			break;
		}
		case ("WeeklyMenu"): {
			int day = 0;
			int meal = 0;
			for (Recipe[] rArray : WeeklyMenu.getRecipesForEachDay()) {
				++day;
				for (Recipe r : rArray) {
					++meal;
					if (r.getRecipeName() != null) {
						System.out.println("Day: " + day + " Meal: " + meal + "\n" + r.toString());
					} else {
						System.out.println("Day: " + day + " Meal: " + meal + "\nTo Be Confirmed.");
					}
				}
				meal = 0;
			}
			break;
		}
		}
	}

	/*
	 * Updates a user-selected ingredient or recipe. Runs toString for all fetched
	 * objects.
	 */
	protected static void updateObject(String type) {
		try {
			switch (type) {
			case "Ingredient":
				if (listOfIngredients.isEmpty()) {
					throw new Exception();
				}
				Ingredient toUpdateI = UtilityInput.takeIngredient(listOfIngredients);
				System.out.print("\nUpdating Ingredient:\n" + toUpdateI.toString()
						+ "\n1: Name\n2: Food Type\n3: Calories Per 100 Grams\n\nSelect field to Update:");
				switch (UtilityInput.takeIntFromScanner()) {
				case 1:
					toUpdateI.setIngredientName(UtilityInput.takeName());
					System.out.println("Name has been updated.");
					break;
				case 2:
					toUpdateI.setFoodType(UtilityInput.takeFoodType());
					System.out.println("Food Type has been updated.");
					break;
				case 3:
					toUpdateI.setCaloriesPer100Grams(UtilityInput.takeCaloriesPer100Grams());
					System.out.println("Calories per 100 Grams has been updated.");
					break;
				default:
					throw new Exception("Invalid Input.");
				}
				break;
			case "Recipe":
				if (listOfRecipes.isEmpty()) {
					throw new Exception();
				}
				Recipe toUpdateR = UtilityInput.takeRecipe(listOfRecipes);
				System.out.print("Updating Recipe:\n" + toUpdateR.toString()
						+ "\n 1: Name\n2: Ingredients\n3: Ingredients Guidance\n4: Method Instructions\n\nSelect field to Update:");
				switch (UtilityInput.takeIntFromScanner()) {
				case 1:
					UtilityInput.takeName();
					System.out.println("Name has been updated.");
					break;
				case 2:
					UtilityInput.takeIngredients(listOfIngredients);
					System.out.println("Ingredients has been updated.");
					break;
				case 3:
					UtilityInput.takeStringArray("IngredientsGuidance", toUpdateR.getIngredients().length);
					System.out.println("Ingredients Guidance has been updated.");
					break;
				case 4:
					UtilityInput.takeStringArray("MethodInstructions", toUpdateR.getIngredients().length);
					System.out.println("Method Instructions has been updated.");
					break;
				default:
					throw new Exception("Invalid Input.");
				}
			}
		} catch (Exception ex) {
			System.out.println("Sorry! There are no " + type + "s saved to be updated.");
		}
	}

	/*
	 * Updates every meal in the weekly menu. Takes details from user.
	 */
	protected static void setAllWeeklyList() {
		if (!listOfRecipes.isEmpty()) {
			while (true) {
				try {
					int countDay = 0;
					int countRecipe = 0;
					Recipe[][] rArray = new Recipe[3][3];
					for (int i = 0; i < weeklyMenu.length; i++) {
						++countDay;
						for (int q = 0; q < weeklyMenu[0].length; q++) {
							++countRecipe;
							rArray[i][q] = UtilityInput.takeMeal(listOfRecipes, countDay, countRecipe);
							if (rArray[i][q] == null) {
								throw new Exception();
							}
						}
						countRecipe = 0;
					}
					WeeklyMenu.setRecipes(rArray);
					System.out.println("\nThe Weekly Menu has been Successfully set.");
					return;
				} catch (Exception ex) {
					System.out.println("Sorry! That input was invalid. Please try again!");
				}
			}
		} else {
			System.out.println("\nSorry, there are no recipes saved to manipulate the weekly menu.");
		}
	}

	/*
	 * Updates every meal in the weekly menu. Takes details from user.
	 */
	protected static void updateAllMeals() {
		if (!listOfRecipes.isEmpty()) {
			while (true) {
				try {
					System.out.print("Taking the day to be updated:\nMonday = 1, Tuesday = 2, etc.\nEnter Selection:");
					int dayToBeUpdated = UtilityInput.takeIntFromScanner();
					if (dayToBeUpdated > 0 && dayToBeUpdated < 8) {
						int countRecipe = 0;
						for (Recipe r : weeklyMenu[dayToBeUpdated]) {
							++countRecipe;
							r = UtilityInput.takeMeal(listOfRecipes, dayToBeUpdated, countRecipe);
							if (r == null) {
								throw new Exception();
							}
						}
						System.out.println("\nThe Meals have been Updated Successfully.");
						return;
					}
					throw new Exception();
				} catch (Exception ex) {
					System.out.println("\nSorry! That input was invalid. Please try again!");
				}
			}
		} else {
			System.out.println("\nSorry, there are no recipes saved to manipulate the weekly menu.");
		}
	}

	/*
	 * Updates one meal in the weekly menu. Takes details from user.
	 */
	protected static void updateOneMeal() {
		if (!listOfRecipes.isEmpty()) {
			while (true) {
				try {
					System.out.print("Taking the day to be updated:\nMonday = 1, Tuesday = 2, etc.\nEnter Selection:");
					int dayToBeUpdated = UtilityInput.takeIntFromScanner();
					System.out.print(
							"Taking the meal to be updated:\nStarter = 1, Main = 2, Dessert = 3\nEnter Selection:");
					int mealToBeUpdated = UtilityInput.takeIntFromScanner();
					if (dayToBeUpdated > 0 && dayToBeUpdated < 8 && mealToBeUpdated > 0 && mealToBeUpdated < 4) {
						UtilityInput.takeMeal(listOfRecipes, dayToBeUpdated, mealToBeUpdated);
						System.out.println("\nThe Meal has been Updated Successfully.");
						return;
					}
					throw new Exception();
				} catch (Exception ex) {
					System.out.println("\nSorry! That input was invalid. Please try again!");
				}
			}
		} else {
			System.out.println("\nSorry, there are no recipes saved to manipulate the weekly menu.");
		}
	}
}