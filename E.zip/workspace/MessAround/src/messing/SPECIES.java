package messing;

public enum SPECIES {
	CANID, FELINE, URSINE, BOVINE, OTHER, UNDEFINED;
	public static SPECIES parse(int input) {
		switch(input) {
		case 0:
			return SPECIES.CANID;
		case 1:
			return SPECIES.FELINE;
		case 2:
			return SPECIES.URSINE;
		case 3:
			return SPECIES.BOVINE;
		case 4:
			return SPECIES.BOVINE;
		default:
			return SPECIES.UNDEFINED;
		}
	}
	public String toString() {
		return this.name().toLowerCase();
	}
}
