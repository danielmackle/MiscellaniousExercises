package messing;

public enum GENDER {
	MALE,FEMALE,OTHER,UNDEFINED;
	public static GENDER parse(int input) {
		switch(input) {
		case 0:
			return GENDER.MALE;
		case 1:
			return GENDER.FEMALE;
		case 2:
			return GENDER.OTHER;
		default:
			return GENDER.UNDEFINED;
		}
	}
	public String toString() {
		return this.name().toLowerCase();
	}
}
