package messing;

public class AnimalTest {
	public static void main(String args[]) {
		Animal mum = new Animal();
		Animal dad = new Animal();
		Animal child = new Animal("Cow", 3,mum, dad,SPECIES.BOVINE,GENDER.MALE);
		System.out.println(child.toString());
	}
}
