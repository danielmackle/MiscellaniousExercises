package studentManagement;

public enum GRADE {
	AStar("A*"),
	A("A"),
	B("B"),
	C("C"),
	D("D"),
	F("F"),
	U("U");
	private String input;
	GRADE(String input){
		this.input = input;
	}
	public String toString() {
		return input;
	}
}
