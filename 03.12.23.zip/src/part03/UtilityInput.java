package part03;
import java.util.ArrayList;
public class UtilityInput {
	/**
	 * Asks for, inputs and validates a string input from Console
	 */
	public static String takeStringFromConsole() {
		try {
			return (String) QUBVisualKitchen.con.readLn();
		} catch (Exception exception) {
			return "ERROR";
		}
	}

	/**
	 * Asks for, inputs and validates an int input from Console
	 */
	public static int takeIntFromConsole() {
		try {
			return Integer.parseInt(QUBVisualKitchen.con.readLn());
		} catch (Exception exception) {
			return -1;
		}
	}

	/**
	 * Asks for, inputs and validates a float input from Console
	 */
	public static float takeFloatFromConsole() {
		try {
			return Float.parseFloat(QUBVisualKitchen.con.readLn());
		} catch (Exception exception) {
			return -1;
		}
	}

	public static boolean takeBooleanFromConsole() throws Exception {
		String selection = (String) QUBVisualKitchen.con.readLn();
		if (selection.equals("y")) {
			return true;
		} else if (selection.equals("n")) {
			return false;
		} else {
			throw new Exception();
		}
	}

	/**
	 * Asks for, inputs and validates an existing Ingredient from Console
	 * 
	 * @param ArrayList<Ingredient> 'listOfIngredients' - holds the existing list of
	 *                              ingredients to find the selected ingredient.
	 * @return Ingredient - output of found ingredient
	 */
	public static Ingredient takeIngredient(ArrayList<Ingredient> listOfIngredients) throws Exception{
		if (listOfIngredients.isEmpty()) {
			throw new ArithmeticException();
		}
		while (true) {
			try {
				QUBVisualKitchen.con.println(
						"Sorting Ingredients by Name:");
				QUBVisualKitchen.con.print("\nSort by ascending?\nPlease type 'y' or 'n':");
				boolean ascending = UtilityInput.takeBooleanFromConsole();
				Utility.sortList(listOfIngredients,null, ascending,"Ingredient");
				QUBVisualKitchen.con.println();
				Utility.ListArrayToStringShort(listOfIngredients);
				QUBVisualKitchen.con.println();
				boolean valid=false;
				while(!valid) {
					ArrayList<Ingredient> ings = Utility.searchIngredientList(listOfIngredients);
					if(!ings.isEmpty()) {
						valid=true;
						QUBVisualKitchen.con.println();
						for(Ingredient i : ings) {
							i.toStringShort();
						}
					}
					else {
						QUBVisualKitchen.con.println("Sorry! No Ingredient under that name was found. Try again!");
					}
				}
				QUBVisualKitchen.con.println();
				while (true) {
					int id = UtilityInput.takeID("Ingredient");
					for (Ingredient i : listOfIngredients) {
						if (id == i.getIngredientID()) {
							return i;
						}
						QUBVisualKitchen.con.println("Sorry, the Ingredient was not found. Please try again!");
					}
				}
			} catch (Exception ex) {
				QUBVisualKitchen.con.println("\nSorry, an input was invalid. Please Try Again!");
			}
		}
	}

	/**
	 * Asks for, inputs and validates an existing Recipe from Console
	 * 
	 * @param ArrayList<Recipe> 'listOfRecipes' - holds the existing list of
	 *                              recipes to find the selected ingredient
	 * @return Recipe - output of found recipe
	 */
	public static Recipe takeRecipe(ArrayList<Recipe> listOfRecipes) throws Exception{
		if (listOfRecipes.isEmpty()) {
			throw new ArithmeticException();
		}
		while (true) {
			try {
				QUBVisualKitchen.con.println(
						"Sorting Recipes by Name:");
				QUBVisualKitchen.con.print("\nSort by ascending?\nPlease type 'y' or 'n':");
				boolean ascending = UtilityInput.takeBooleanFromConsole();
				Utility.sortList(null,listOfRecipes, ascending,"Recipe");
				Utility.ListArrayToStringShortR(listOfRecipes);
				boolean valid=false;
				while(!valid) {
					ArrayList<Recipe> recs = Utility.searchRecipeList(listOfRecipes);
					if(!recs.isEmpty()) {
						valid=true;
						QUBVisualKitchen.con.println();
						for(Recipe r : recs) {
							r.toStringShort();
						}
					}
					else {
						QUBVisualKitchen.con.println("Sorry! No Recipe under that name was found. Try again!");
					}
				}
				QUBVisualKitchen.con.println();
				while (true) {
					int id = UtilityInput.takeID("Recipe");
					for (Recipe r : listOfRecipes) {
						if (id == r.getRecipeID()) {
							return r;
						}
						QUBVisualKitchen.con.println("Sorry, the Recipe was not found. Please try again!");
					}
				}
			}catch (Exception ex) {
				QUBVisualKitchen.con.println("\nSorry, an input was invalid. Please Try Again!");
			}
		}
	}

	/**
	 * Asks for, inputs and validates an existing Ingredient from Console
	 * 
	 * @param String 'type' - Used to tell between method calls
	 * @return Recipe - output of found recipe
	 */
	public static int takeID(String type) throws Exception {

		while (true) {
			QUBVisualKitchen.con.print("Please enter ID of " + type + ":");
			int id = UtilityInput.takeIntFromConsole();
			if (id >= 0) {
				return id;
			} else {
				QUBVisualKitchen.con.println("\nSorry, that ID was invalid. Please try Again!\n");
			}
		}
	}

	/**
	 * Takes String input and validates whether it is valid or invalid.
	 */
	public static String takeName() {
		String name;
		while (true) {
			QUBVisualKitchen.con.print("\nAdding a Name:\nPlease Enter a Name:");
			name = UtilityInput.takeStringFromConsole();
			if (name != "ERROR") {
				return name;
			} else {
				QUBVisualKitchen.con.println("\nSorry, that input was invalid. Please try Again!\n");
			}
		}
	}

	/**
	 * Takes FoodType input and validates whether it is valid or invalid.
	 */
	public static FOODTYPE takeFoodType() {
		while (true) {
			QUBVisualKitchen.con.print(
					"\nAdding a Food Type:\n1: Dairy\n2: Cereal\n3: Fruit & Veg\n4: Protein\n5: Sugar\n6: Fat\n7: Composite Food\n8: Spice & Herb\n9: Essential Nutrient\nPlease Enter Selection:");
			int index = UtilityInput.takeIntFromConsole();
			switch (index) {
			case (1):
				return FOODTYPE.DAIRY;
			case (2):
				return FOODTYPE.CEREAL;
			case (3):
				return FOODTYPE.FRUITANDVEG;
			case (4):
				return FOODTYPE.PROTEIN;
			case (5):
				return FOODTYPE.SUGAR;
			case (6):
				return FOODTYPE.FAT;
			case (7):
				return FOODTYPE.COMPOSITEFOOD;
			case (8):
				return FOODTYPE.SPICEANDHERB;
			case (9):
				return FOODTYPE.ESSENTIALNUTRIENT;
			default:
				QUBVisualKitchen.con.println("\nSorry, that input was invalid. Please try Again!\n");
			}
		}
	}

	/**
	 * Takes float input and validates whether it is valid or invalid.
	 */
	public static float takeCaloriesPer100Grams() {
		float caloriesPer100Grams;
		while (true) {
			QUBVisualKitchen.con.print("\nAdding the Caloric Details:\nPlease enter the Calories per 100 grams:");
			caloriesPer100Grams = UtilityInput.takeFloatFromConsole();
			if (caloriesPer100Grams != -1) {
				return caloriesPer100Grams;
			} else {
				QUBVisualKitchen.con.println("\nSorry, that input was invalid. Please try Again!\n");
			}
		}
	}

	/**
	 * Asks for, inputs and validates an existing Ingredient array from Console
	 * 
	 * @param ArrayList<Ingredient> 'listOfIngredients' - holds the existing list of
	 *                              ingredients to find the selected ingredient.
	 * @return Ingredient[] - output of found ingredieng array
	 */
	public static Ingredient[] takeIngredients(ArrayList<Ingredient> listOfIngredients) {
		while (true) {
			try {
				QUBVisualKitchen.con.print("\nSelecting the Ingredients:\nPlease enter the number of Ingredient Types to Add:");
				int amountOfIngredients = UtilityInput.takeIntFromConsole();
				Ingredient[] ingredients = new Ingredient[amountOfIngredients];
				for (int i = 0; i < amountOfIngredients; i++) {
					QUBVisualKitchen.con.println("\nIngredient " + (i + 1) + ":");
					ingredients[i] = UtilityInput.takeIngredient(listOfIngredients);
				}
				return ingredients;
			} catch (Exception ex) {
				QUBVisualKitchen.con.println("\nSorry, that Ingredient was invalid. Please try Again!\n");
			}
		}
	}

	/**
	 * Asks for, inputs and validates an existing Ingredient array from Console
	 * 
	 * @param String 'type' - Used to tell between method calls
	 * @param int    'amountOfIngredients' - holds the amount of ingredients to have
	 *               a string taken for
	 * @return String[] - output of taken String array
	 */
	public static String[] takeStringArray(String type, int amountOfIngredients) {
		while (true) {
			try {
				switch (type) {
				case ("IngredientsGuidance"):
					QUBVisualKitchen.con.println("\nSelecting the Ingredients Guidance:");
					String[] ingredientsGuidance = new String[amountOfIngredients];
					for (int i = 0; i < amountOfIngredients; i++) {
						QUBVisualKitchen.con.println("Ingredient Guidance " + (i + 1) + ":");
						ingredientsGuidance[i] = UtilityInput.takeStringFromConsole();
					}
					return ingredientsGuidance;
				case ("MethodInstructions"):
					QUBVisualKitchen.con.println("\nSelecting the Method Instructions:");
					String[] recipeInstructions = new String[amountOfIngredients];
					for (int i = 0; i < amountOfIngredients; i++) {
						QUBVisualKitchen.con.println("Recipe Instruction " + (i + 1) + ":");
						recipeInstructions[i] = UtilityInput.takeStringFromConsole();
					}
					return recipeInstructions;
				}
			} catch (Exception ex) {
				QUBVisualKitchen.con.println("\nSorry, that " + type + " was invalid. Please try Again!\n");
			}
		}
	}

	public static Recipe takeMeal(ArrayList<Recipe> listOfRecipes, int countDay, int countRecipe) {
		while(true) {
			try {
				QUBVisualKitchen.con.println("Day: " + countDay + ", Meal: " + countRecipe);
				Recipe r = UtilityInput.takeRecipe(listOfRecipes);
				if (r == null) {
					throw new Exception();
				}
				return r;
			}
			catch(Exception ex) {}
		}
	}
}
