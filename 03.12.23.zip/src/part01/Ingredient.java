/**
 * @author Daniel Mackle
 * @id 40407187
 * @date 11/11/2023
 */
package part01;

import java.util.ArrayList;

/**
 * Holds data of a specific type of ingredient. Only holds data, does not
 * manipulate data.
 */
public class Ingredient {
	// Private Instance Variables
	/**
	 * Holds the unique ID of the ingredient
	 */
	private int ingredientID;
	/**
	 * Holds the name the ingredient
	 */
	private String ingredientName;
	/**
	 * Holds the enum foodtype of the ingredient
	 */
	private FOODTYPE foodType;
	/**
	 * Holds the floating point value for the caloric energy of the ingredient per
	 * 100 grams
	 */
	private float caloriesPer100Grams;
	// Private Class Variables
	// holds the number of the ID of the next instance. Is appreciated upon
	// successful instantiation.
	private static int nextIngredientID = 0;

	// Public Constructors
	/**
	 * Empty Constructor
	 */
	public Ingredient() {
	}

	/**
	 * Constructor - Saves full data of Object
	 * 
	 * @param String   'ingredientName' - name of ingredient
	 * @param FOODTYPE 'foodType' - food type (enumerated)
	 * @param int      'amountHeld' - amount of ingredients per instance of an
	 *                 ingredient type
	 * @param float    'caloriesPer100Grams' - name of ingredient
	 * @throws Exception
	 */
	public Ingredient(String ingredientName, FOODTYPE foodType, float caloriesPer100Grams) throws Exception {
		setIngredientID(getNextIngredientID());
		try {
			setIngredientName(ingredientName);
			setFoodType(foodType);
			setCaloriesPer100Grams(caloriesPer100Grams);
		} catch (Exception exception) {
			throw new Exception();
		}
	}

	// Public Properties
	/**
	 * Accessor
	 * @return integer ingredientID
	 */
	public int getIngredientID() {
		return this.ingredientID;
	}

	/**
	 * Sccessor - increases this.nextIngredientID after returning
	 * 
	 * @return static integer nextIngredientID
	 */
	public int getNextIngredientID() {
		return nextIngredientID++;
	}

	/**
	 * accessor
	 * @return String ingredientName
	 */
	public String getIngredientName() {
		return this.ingredientName;
	}

	/**
	 * accessor
	 * @return integer foodType
	 */
	public FOODTYPE getFoodType() {
		return this.foodType;
	}

	/**
	 * accessor
	 * @return float caloriesPer100Grams
	 */
	public float getCaloriesPer100Grams() {
		return this.caloriesPer100Grams;
	}

	/**
	 * mutator - checks validation with Util
	 * @param ingredientID - new Unique ID of the type of Ingredient
	 * @throws Exception
	 */
	public void setIngredientID(int ingredientID) throws Exception {
		if (!Utility.validatePositiveInt(ingredientID)) {
			throw new Exception();
		}
		this.ingredientID = ingredientID;
	}

	/**
	 * mutator - checks validation with Util
	 * @param ingredientName - new name of the type of Ingredient
	 * @throws Exception
	 */
	public void setIngredientName(String ingredientName) throws Exception {
		if (!Utility.validateString(ingredientName)|| ingredientName.length()>25) {
			throw new Exception();
		}
		this.ingredientName = ingredientName;
	}

	/**
	 * mutator - checks validation with Util
	 * @param foodType - new food type of the ingredient
	 * @throws Exception
	 */
	public void setFoodType(FOODTYPE foodType) throws Exception {
		if (!Utility.validateFOODTYPE(foodType)) {
			throw new Exception();
		}
		this.foodType = foodType;
	}

	/**
	 * mutator - checks validation with Util
	 * @param caloriesPer100Grams - the calories Per 100 Grams of the Ingredient
	 * @throws Exception
	 */
	public void setCaloriesPer100Grams(float caloriesPer100Grams) throws Exception {
		if (!Utility.validatePositiveFloat(caloriesPer100Grams)) {
			throw new Exception();
		}
		this.caloriesPer100Grams = caloriesPer100Grams;
	}

	// Public Methods
	/**
	 * uses inputed ID to return the corresponding ingredient in the inputed list.
	 * output the ingredient or null if the ingredient is not found
	 * 
	 * @param id                - id of ingredient
	 * @param listOfIngredients - list to search through
	 * @return Ingredient - the found reference to the Ingredient
	 */
	public static Ingredient getIngredientFromID(int id, ArrayList<Ingredient> listOfIngredients) {
		for (Ingredient ingredient : listOfIngredients) {
			if (ingredient.getIngredientID() == id) {
				return ingredient;
			}
		}
		return null;
	}

	/**
	 * delete the ingredient of a given id from a given list
	 * @param id - id of ingredient to delete
	 * @param listOfIngredients - list of ingredients for the ingreident to be deleted from
	 */
	public static void deleteIngredient(Ingredient id, ArrayList<Ingredient> listOfIngredients) {
		if (id != null) {
			listOfIngredients.remove(id);
			System.out.println("\nThe Ingredient has been deleted.");
		}
	}

	/**
	 * Returns a String representing the state of the instance
	 * @return String - message tied to enumerated type
	 */
	public String toString() {
		return "Ingredient ID:" + this.getIngredientID() + "\nIngredient Name: " + this.getIngredientName()
				+ "\nFood Type: " + this.getFoodType() + "\nCalories Per 100 Grams: " + this.getCaloriesPer100Grams();
	}

	public void toStringShort() {
		System.out.println("ID: " + this.getIngredientID() + " Name: " + this.getIngredientName());
	}
}