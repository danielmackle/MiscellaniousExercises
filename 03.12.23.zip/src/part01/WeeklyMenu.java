/**
 * @author Daniel Mackle
 * @id 40407187
 * @date 13/11/2023
 */
package part01;

/**
 * Holds data of the weekly menu
 */
public abstract class WeeklyMenu {
	/**
	 * Holds the 2d array of Recipe for each meal of each day. LetRecipe[x][y] x=day y=course
	 */
	private static Recipe[][] recipesForEachDay;

	/**
	 * Accessor
	 * @return Recipe[][] - Accessed Data
	 */
	public static Recipe[][] getRecipesForEachDay() {
		return recipesForEachDay;
	}

	/**
	 * Mutator - checks validation with Util - must not be null
	 * @param recipesForEachDayInput - 2d Recipe array representing WeeklyMenu data
	 * @throws Exception
	 */
	public static void setRecipes(Recipe[][] recipesForEachDayInput) 
			throws Exception {
		recipesForEachDay = recipesForEachDayInput;
	}
	
	/**
	 * ToString Alternative
	 * @return returns the ToString() of every Recipe object held in the 2dArray
	 */
	public static String getDetailsAsString() {
		return Utility.recipe2DArrayToString(getRecipesForEachDay());
	}
}
