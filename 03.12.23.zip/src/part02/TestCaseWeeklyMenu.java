package part02;

import part01.Recipe;
import part01.WeeklyMenu;

public class TestCaseWeeklyMenu extends TestCases {
	public static void testCases(int selection) {
		switch (selection) {
		case (28):
			testCase28();
			break;
		case (29):
			testCase29();
			break;
		case (30):
			testCase30();
			break;
		case (31):
			testCase31();
			break;
		}
	}

	public static void testCase28() {
		try {
			testCaseStart(28, "Weekly Menu Management", "Filling the Weekly Menu with preset Recipes.");

			WeeklyMenu.setRecipes(getPremadeRecipeArray());

			System.out.print("\nOutput:\n");
			viewAllObject("WeeklyMenu");
			testCaseEnd();
			WeeklyMenu.setRecipes(new Recipe[3][3]);
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}

	public static void testCase29() {
		try {
			testCaseStart(29, "Weekly Menu Management", "Filling the Weekly Menu with null Recipes.");

			WeeklyMenu.setRecipes(null);

			System.out.print("\nOutput:\n");
			viewAllObject("WeeklyMenu");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}

	public static void testCase30() {
		try {
			testCaseStart(30, "Weekly Menu Management", "View the valid Weekly Menu.");

			createPremadeWeeklyMenu();

			System.out.print("\nOutput:\n");
			viewAllObject("WeeklyMenu");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}

	public static void testCase31() {
		try {
			testCaseStart(31, "Weekly Menu Management", "View the null invalid Weekly Menu.");

			System.out.print("\nOutput:\n");
			viewAllObject("WeeklyMenu");
			testCaseEnd();
			return;
		} catch (Exception ex) {
			System.out.println("#########Exception Handled#########"); testCaseEnd();
		}
	}
}
