package part02;

import part01.*;

public class TestCases extends QUBKitchen {
	public static void main(String[] args) {
		selectTestCase();
	}

	private static void selectTestCase() {
		while (true) {
			listOfIngredients.clear();
			listOfRecipes.clear();
			try {
				WeeklyMenu.setRecipes(new Recipe[3][3]);
			} catch (Exception e) {}
			weeklyMenu = new Recipe[3][3];
			try {
				System.out.print("Enter Number of Test Case: ");
				int selection = UtilityInput.takeIntFromScanner();
				if (selection > 0 && selection < 14|selection > 43 && selection < 46) {
					TestCaseIngredient.testCases(selection);
				} else if (selection > 13 && selection < 28|selection > 45 && selection < 48) {
					TestCaseRecipe.testCases(selection);
				} else if (selection > 27 && selection < 32) {
					TestCaseWeeklyMenu.testCases(selection);
				} else if (selection > 31 && selection < 44|selection > 47 && selection < 50) {
					TestCaseUtility.testCases(selection);
				}
				else {
					throw new Exception();
				}
			} catch (Exception ex) {
				System.out.println("Please enter a valid number representing a Test case.");
			}
		}
	}

	protected static void createPremadeIngredient() throws Exception {
		System.out.println("Input:\nName-Beef\nFoodType-FoodType.Protein\nCaloriesPer100Grams- 20");
		Ingredient toAdd = new Ingredient("Beef", FOODTYPE.PROTEIN, 20);
		listOfIngredients.add(toAdd);
	}

	protected static void createPremadeRecipe() throws Exception {
		createPremadeIngredient();
		System.out.println(
				"Input:\nName-'Beef Stew'\nIngredients: [Beef]\nIngredients Guidance-'100 grams'\nRecipe Instructions - 'Seperate then fry'");
		listOfRecipes.add(new Recipe("Beef Stew", new Ingredient[] { listOfIngredients.get(0) }, new String[] { "100 grams" },
				new String[] { "Seperate then Fry" }));
	}
	
	protected static void createPremadeIngredients() throws Exception {
		createPremadeIngredient();
		System.out.println("Input:\nName-Chicken\nFoodType-FoodType.Protein\nCaloriesPer100Grams- 20");
		Ingredient toAdd = new Ingredient("Chicken", FOODTYPE.PROTEIN, 20);
		listOfIngredients.add(toAdd);
		System.out.println("Input:\nName-Pork\nFoodType-FoodType.Protein\nCaloriesPer100Grams- 20");
		toAdd = new Ingredient("Pork", FOODTYPE.PROTEIN, 20);
		listOfIngredients.add(toAdd);
	}
	protected static void createPremadeRecipes() throws Exception {
		createPremadeIngredients();
		createPremadeRecipe();
		System.out.println(
				"Input:\nName-'Chicken Stew'\nIngredients: [Chicken]\nIngredients Guidance-'300 grams'\nRecipe Instructions - 'Seperate then fry'");
		listOfRecipes.add(new Recipe("Beef Stew", new Ingredient[] { listOfIngredients.get(1) }, new String[] { "100 grams" },
				new String[] { "Seperate then Fry" }));
		System.out.println(
				"Input:\nName-'Pork Stew'\nIngredients: [Pork]\nIngredients Guidance-'200 grams'\nRecipe Instructions - 'Seperate then fry'");
		listOfRecipes.add(new Recipe("Beef Stew", new Ingredient[] { listOfIngredients.get(2) }, new String[] { "100 grams" },
				new String[] { "Seperate then Fry" }));
	}

	protected static void createPremadeWeeklyMenu() throws Exception {
		createPremadeRecipe();
		System.out.println("Input:\nWeekly menu filled with Beef Stew");
		for (Recipe[] rArray : weeklyMenu) {
			for (@SuppressWarnings("unused") Recipe r : rArray) {
				r = listOfRecipes.get(0);
			}
		}
	}
	
	protected static Recipe[][] getPremadeRecipeArray() throws Exception {
		createPremadeRecipe();
		System.out.println("Input:\nRecipe array filled with beef stew");
		Recipe[][] rArray = new Recipe[3][3];
		for (int i=0; i< weeklyMenu.length;i++) {
			for (int q=0; q< weeklyMenu[0].length;q++) {
				rArray[i][q]= listOfRecipes.get(0);
			}
		}
		return rArray;
	}

	protected static void testCaseStart(int numbered, String group, String desc) {
		System.out.println("\n#########START TEST CASE#########" + "\nTest Case: " + numbered + "\nDescription:" + desc);
	}

	protected static void testCaseEnd() {
		System.out.println("#########END TEST CASE#########");
	}
}
